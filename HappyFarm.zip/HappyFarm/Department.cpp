#include<iostream>
#include<cstdio>
#include <string>
#include "Department.h"

int Department::sum = 0;

Department::Department()
{
	dept_name = "";
	dept_id = -1;
}

Department::~Department() {
    
}

void Department::notifyMeeting() {
	for (int i = 0; i < staffs.size(); i++)
	{
        staffs[i]->goodMeeting();
	}
}

    //---------------------

Feeding::Feeding()
{
    dept_name="Feeding";
    dept_id = 2;
    sum = 0;
        //    Department::department_staff.push_back(&staffs);
    
}

void Feeding::createStaff(string name)
{
    staffs.push_back(new Feeder(name));
}

bool Feeding::removeStaff(int staff_id)
{
    for (int i = 0; i< staffs.size(); ++i)
        if (staffs[i]->getID() == staff_id) {
            for (int j = i + 1; j < staffs.size(); ++j) staffs[j - 1] = staffs[j];
            delete *(staffs.end()-1);
            staffs.pop_back();
            return true;
        }
    cout << "staff with ID " << staff_id << "may not exist in feeding department"  << endl;
    return false;
}

void Feeding::showStaff()
{
    for (int i = 0; i < staffs.size(); ++i) {
        cout << staffs[i]->getInfo() << endl;
    }
}

Staff* Feeding::assignJob(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            staffs[i]->work();
            cout <<"Feeding: assignJob: assign job to " << staffs[i]->getInfo() << " successfully!" << endl;
            return staffs[i];
        }
    }
    cout << "Feeding: assignJob: the target staff with ID "<< ID <<" either not exists or is not a feeder"<< endl;
    return NULL;
}

Staff* Feeding::findStaff(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            return staffs[i];
        }
    }
    return NULL;
}
    //--------------------
Hospital::Hospital()
{
    dept_name = "Hospital";
    dept_id = 3;
    sum = 0;
        //     Department::department_staff.push_back(&staffs);
    
}

void Hospital::createStaff(string name)
{
    staffs.push_back(new Vetaritarian(name));
}

bool Hospital::removeStaff(int staff_id)
{
    for (int i = 0; i<staffs.size(); ++i)
        if (staffs[i]->getID() == staff_id) {
            for (int j = i + 1; j < staffs.size(); ++j) staffs[j - 1] = staffs[j];
            delete *(staffs.end()-1);
            staffs.pop_back();
            return true;
        }
    cout << "staff with ID " << staff_id << "may not exist in hospital"  << endl;
    
    return false;
}

void Hospital::showStaff()
{
    for (int i = 0; i < staffs.size(); ++i) {
        cout << staffs[i]->getInfo() << endl;
    }
}

Staff* Hospital::assignJob(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            staffs[i]->work();
            cout <<"Hospital: assignJob: assign job to " << staffs[i]->getInfo() << " successfully!" << endl;
            return staffs[i];
        }
    }
    cout << "Hospital: assignJob: the target staff with ID "<< ID <<" either not exists or is not a vetaritarian"<< endl;
    return NULL;
}

Staff* Hospital::findStaff(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            return staffs[i];
        }
    }
    return NULL;
}
    //--------------------
Cleaning::Cleaning()
{
    dept_name = "Cleaning";
    dept_id = 1;
    sum = 0;
        //    Department::department_staff.push_back(&staffs);
}

void Cleaning::createStaff(string name)
{
    staffs.push_back(new Cleaner(name));
}

bool Cleaning::removeStaff(int staff_id)
{
    for (int i = 0; i<staffs.size(); ++i)
        if (staffs[i]->getID() == staff_id) {
            for (int j = i + 1; j < staffs.size(); ++j) staffs[j - 1] = staffs[j];
            delete *(staffs.end()-1);
            staffs.pop_back();
            return true;
        }
    cout << "staff with ID " << staff_id << "may not exist in Cleaning department"  << endl;
    
    return false;
}

void Cleaning::showStaff()
{
    for (int i = 0; i < staffs.size(); ++i) {
        cout << "Cleaning: showStaff: " << staffs[i]->getInfo() << endl;
    }
}

Staff* Cleaning::assignJob(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            staffs[i]->work();
            cout <<"Cleaning: assignJob: assign job to " << staffs[i]->getInfo() << " successfully!" << endl;
            return staffs[i];
        }
    }
    cout << "Cleaning: assignJob: the target staff with ID "<< ID <<" either not exists or is not a cleaner"<< endl;
    
    return NULL;
}


Staff* Cleaning::findStaff(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            return staffs[i];
        }
    }
    return NULL;
}
    //-------------------------------
