#pragma once
#include <iostream>
#include "CallStrategy.h"
#include "ConcreteCallStrategy.h"
#include "Iterator.h"
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Food.h"
#include "SubFood.h"

using namespace std;

class AnimalNum
{
public:
	AnimalNum()
	{
		for (int i = 0; i < 7; i++)
			_animalNum[i] = 0;
	}
	static void ShowAnimals()
	{
		cout << "Sheep:" << _animalNum[0] << endl;
		cout << "Cattle: " << _animalNum[1] << endl;
		cout << "Chicken:" << _animalNum[2] << endl;
		cout << "Duck: " << _animalNum[3] << endl;
		cout << "Fish: " << _animalNum[4] << endl;
		cout << "Pig: " << _animalNum[5] << endl;
		cout << "Dog: " << _animalNum[6] << endl;
	}
	static void addNum(int species)
	{
		_animalNum[species - 1] = _animalNum[species - 1] + 1;
	}
	static void reduceNum(int species)
	{
		_animalNum[species - 1] = _animalNum[species - 1] - 1;
	}
private:
	static int _animalNum[7];
};

class Animal
{
private:

public:
	//Set call strategy
	virtual bool setCallStrategy(int species, int state);
	virtual void doCall();
	//Construction function
	Animal(int species, string name, int sex) :_species(species), _name(name), _sex(sex) {};
	Animal() {};
	//Destructor function
	~Animal();
	//Born child
	virtual void BornChild();
	//Create iterator
	Iterator<Animal>* createIterator();
	// [] operation overloading
	Animal* operator[](int index);
	//Get child number
	virtual int getChild() { return int(_objects.size()); }
	//Get name
	string getName() { return _name; }
	//Get Sex
	string getSex();
	string Species();
	//Get all numbers of this species
	virtual Animal* Pop(const int cur);
	//Eat food
	virtual void Eat(FoodType foodType);
	//virtual void doEat() = 0;
	virtual void doExercise(string ss, string s) = 0;
	//bool killChild(string name);
protected:
	//Enum of Animal type
	enum SpeciesType
	{
		Sheep = 1, Cattle, Chicken, Duck, Fish, Pig, Dog
	};
	//Enum of Animal sex
	enum SexType
	{
		Male = 1, Female
	};
	//Food* _food;
	int _species;
	string _name;
	int _sex;
	CallStrategy* _callStrategy;
	vector<Animal*> _objects;
	//Add an animal to the list
	//void addAnimal(int species, string name, int sex);
	//Remove an animal
	Animal* removeAnimal(string name, Animal* del_animal, bool& isRemoved);
	//Create a new Animal
	virtual Animal* CreateAnimal(int species, string name, int sex) = 0;
	virtual void doEat() = 0;
public:
	int getSpecies();
	//Find an Animal by name
	//Animal* Find(string const name, Animal* s_animal);
};



//Animal List
template<class Item>
class AnimalList : public Animal
{
public:
	AnimalList() :Animal() {};
	AnimalList(int species, string name, int sex) : Animal(species, name, sex) {}
	void addAnimal(int species, string name, int sex)
	{
		Animal* newAnimal = (Animal*)CreateAnimal(species, name, sex);
		_objects.push_back(newAnimal);
		AnimalNum::addNum(species);
	}
	void addAnimal(Animal* newAnimal)
	{
		if (newAnimal->getSpecies() == Sheep)
			cout << "Sheep: ";
		else if (newAnimal->getSpecies() == Cattle)
			cout << "Cattle: ";
		else if (newAnimal->getSpecies() == Chicken)
			cout << "Chicken: ";
		else if (newAnimal->getSpecies() == Duck)
			cout << "Duck: ";
		else if (newAnimal->getSpecies() == Fish)
			cout << "Fish: ";
		else if (newAnimal->getSpecies() == Pig)
			cout << "Pig: ";
		else if (newAnimal->getSpecies() == Dog)
			cout << "Dog: ";
		cout << newAnimal->getName() << ": " << newAnimal->getSex() << ": Created!" << endl;
		_objects.push_back(newAnimal);
		AnimalNum::addNum(newAnimal->getSpecies());
	}
	Item* Remove(string name)
	{
		bool isRemoved = false;
		return (Item*)removeAnimal(name, this, isRemoved);
	}
	Item* Find(string const name)
	{
		Animal* animal = this;
		bool isFind = false;
		animal = Find(name, this, isFind);
		return (Item*)animal;
	}
	//Get the amount of this species
	int getSize()
	{
		int size = 0;
		Iterator<Animal> *iter = createIterator();
		if (iter == NULL)
			return 0;
		//iter->next();
		while (!iter->isDone())
		{
			size += getSize(iter->currentItem());
			iter->next();
		}
		return size;
	}
private:
	virtual void doEat() {}
	virtual void doExercise(string ss, string s) {}
	//virtual bool setCallStrategy(int species, int state) { return false; }
	//virtual void doCall(){}
	//virtual void BornChild(){}
	//virtual int getChild() { return 0; }
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		if (species == Sheep)
			cout << "Sheep: ";
		else if (species == Cattle)
			cout << "Cattle: ";
		else if (species == Chicken)
			cout << "Chicken: ";
		else if (species == Duck)
			cout << "Duck: ";
		else if (species == Fish)
			cout << "Fish: ";
		else if (species == Pig)
			cout << "Pig: ";
		else if (species == Dog)
			cout << "Dog: ";
		cout << name << ": ";
		if (sex == Male)
			cout << "Male: ";
		else if (sex == Female)
			cout << "Feamale: ";
		cout << "Created!\n";
		return new AnimalList(species, name, sex);
	}
	Item* Find(string const name, Animal* s_animal, bool& isFind)
	{
		Animal* animal = this;
		Iterator<Animal>* iter = s_animal->createIterator();
		if (iter == NULL)
			return NULL;
		while (!iter->isDone())
		{
			if (isFind)
				break;
			animal = Find(name, iter->currentItem(), isFind);
			if (iter->currentItem()->getName() == name)
			{
				animal = iter->currentItem();
				isFind = true;
				break;
			}
			else
				iter->next();
		}
		if (!isFind)
			return NULL;
		else
			return (Item*)animal;
	}
	int getSize(Animal* animal)
	{
		int size = 0;
		Iterator<Animal>* iter = animal->createIterator();
		if (iter == NULL)
			return 0;
		if (animal->getChild() == 0)  //No child
			return 1;
		else
		{
			while (!iter->isDone())
			{
				size += getSize(iter->currentItem());
				iter->next();
			}
			size++;
		}
		return size;
	}
};

//Sheep
class Sheep : public Animal
{

public:
	Sheep(int species, string name, int sex) : Animal(species, name, sex) {}
	Sheep() :Animal() {};
	virtual ~Sheep() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Sheep: " << ss << ": " << s << ": " << "Sheep moring exercise: Walking." << endl;
	}
private:
	//virtual int getSize(){}
	//virtual Animal* Pop(const int cur){}
	virtual void doEat()
	{
		cout << "Sheep: " << _name << ": " << getSex() << ": " << "Eat sheep foods" << endl;
		cout << "Food for sheep: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Sheep: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Sheep(species, name, sex);
	}
};

//Cattle
class Cattle : public Animal
{

public:
	Cattle(int species, string name, int sex) : Animal(species, name, sex) {}
	Cattle() :Animal() {};
	virtual ~Cattle() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Cattle: " << ss << ": " << s << ": " << "Cattle moring exercise: Sunbathing." << endl;
	}
private:
	//virtual int getSize(){}
	//virtual Animal* Pop(const int cur){}
	virtual void doEat()
	{
		cout << "Cattle: " << _name << ": " << getSex() << ": " << "Eat cattle foods" << endl;
		cout << "Food for cattle: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Cattle: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Cattle(species, name, sex);
	}
};

//Chicken
class Chicken : public Animal
{

public:
	Chicken(int species, string name, int sex) : Animal(species, name, sex) {}
	Chicken() :Animal() {};
	virtual ~Chicken() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Chicken: " << ss << ": " << s << ": " << "Chicken moring exercise: Singing." << endl;
	}

private:
	//virtual int getSize() {}
	//virtual Animal* Pop(const int cur) {}
	virtual void doEat()
	{
		cout << "Chicken: " << _name << ": " << getSex() << ": " << "Eat chicken foods" << endl;
		cout << "Food for chicken: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Chicken: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Chicken(species, name, sex);
	}
};

//Duck
class Duck : public Animal
{

public:
	Duck(int species, string name, int sex) : Animal(species, name, sex) {}
	Duck() :Animal() {};
	virtual ~Duck() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Duck: " << ss << ": " << s << ": " << "Duck moring exercise: Swimming." << endl;
	}
private:
	virtual void doEat()
	{
		cout << "Duck: " << _name << ": " << getSex() << ": " << "Eat duck foods" << endl;
		cout << "Food for duck: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Duck: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Duck(species, name, sex);
	}
};

//Fish
class Fish : public Animal
{

public:
	Fish(int species, string name, int sex) : Animal(species, name, sex) {}
	Fish() :Animal() {};
	virtual ~Fish() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Fish: " << ss << ": " << s << ": " << "Fish moring exercise: Spit bubbles." << endl;
	}
private:
	//virtual int getSize() {}
	//virtual Animal* Pop(const int cur) {}
	virtual void doEat()
	{
		cout << "Fish: " << _name << ": " << getSex() << ": " << "Eat fish foods" << endl;
		cout << "Food for fish: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Fish: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Fish(species, name, sex);
	}
};

//Pig
class Pig : public Animal
{

public:
	Pig(int species, string name, int sex) : Animal(species, name, sex) {}
	Pig() :Animal() {};
	virtual ~Pig() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Pig: " << ss << ": " << s << ": " << "Pig moring exercise: Sleeping." << endl;
	}
private:
	//virtual int getSize() {}
	//virtual Animal* Pop(const int cur) {}
	virtual void doEat()
	{
		cout << "Pig: " << _name << ": " << getSex() << ": " << "Eat pig foods" << endl;
		cout << "Food for pig: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Pig: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Pig(species, name, sex);
	}
};

//Dog
class Dog : public Animal
{

public:
	Dog(int species, string name, int sex) : Animal(species, name, sex) {}
	Dog() :Animal() {};
	virtual ~Dog() {}
	virtual void doExercise(string ss, string s)
	{
		cout << "Dog: " << ss << ": " << s << ": " << "Dog moring exercise: Guard." << endl;
	}
private:
	//virtual int getSize() {}
	//virtual Animal* Pop(const int cur) {}
	virtual void doEat()
	{
		cout << "Dog: " << _name << ": " << getSex() << ": " << "Eat dog foods" << endl;
		cout << "Food for dog: " << endl;
	}
	virtual Animal* CreateAnimal(int species, string name, int sex)
	{
		cout << "Dog: " << name << ": ";
		if (sex == 1)
			cout << "male: ";
		else
			cout << "female: ";
		cout << "Created!" << endl;
		return new Dog(species, name, sex);
	}
};

//Proxy Sheep
class ProxySheep {
	Sheep* real_sheep_sport;
public:
	ProxySheep() {
		real_sheep_sport = 0;
	}
	~ProxySheep() {
		delete real_sheep_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_sheep_sport)
			real_sheep_sport = new Sheep();
		real_sheep_sport->doExercise(ss, s);
	}
};

//Proxy Cattle
class ProxyCattle {
	Cattle* real_cow_sport;
	string ss;
public:
	ProxyCattle() {
		real_cow_sport = 0;
	}
	~ProxyCattle() {
		delete real_cow_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_cow_sport)
			real_cow_sport = new Cattle();
		real_cow_sport->doExercise(ss, s);
	}
};

//Proxy Chicken
class ProxyChicken {
	Chicken* real_chicken_sport;
public:
	ProxyChicken() {
		real_chicken_sport = new Chicken;
	}
	~ProxyChicken() {
		delete real_chicken_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_chicken_sport)
			real_chicken_sport = new Chicken();
		real_chicken_sport->doExercise(ss, s);
	}
};

// Proxy Duck
class ProxyDuck {
	Duck* real_duck_sport;
public:
	ProxyDuck() {
		real_duck_sport = 0;
	}
	~ProxyDuck() {
		delete real_duck_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_duck_sport)
			real_duck_sport = new Duck();
		real_duck_sport->doExercise(ss, s);
	}
};

// Proxy Fish
class ProxyFish {
	Fish* real_fish_sport;
public:
	ProxyFish() {
		real_fish_sport = 0;
	}
	~ProxyFish() {
		delete real_fish_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_fish_sport)
			real_fish_sport = new Fish();
		real_fish_sport->doExercise(ss, s);
	}
};

//Proxy Pig
class ProxyPig {
	Pig* real_pig_sport;
public:
	ProxyPig() {
		real_pig_sport = 0;
	}
	~ProxyPig() {
		delete real_pig_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_pig_sport)
			real_pig_sport = new Pig();
		real_pig_sport->doExercise(ss, s);
	}
};

//Proxy Dog
class ProxyDog {
	Dog* real_dog_sport;
	string ss;
public:
	ProxyDog() {
		real_dog_sport = 0;
	}
	~ProxyDog() {
		delete real_dog_sport;
	}
	void doExercise(string ss, string s) {
		if (!real_dog_sport)
			real_dog_sport = new Dog();
		real_dog_sport->doExercise(ss, s);
	}
};
