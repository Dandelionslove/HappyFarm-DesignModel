#ifndef Staff_hpp
#define Staff_hpp

#include <iostream>
#include "Status.h"
#include "Food.h"
class State;
using namespace std;

class StaffContext {
public:
    virtual void goodMeeting() = 0;
    virtual void goodWorking() = 0;
    virtual void callingIll() = 0;
    virtual void changeState(State* state) = 0;
};

class Staff: public StaffContext {
protected:
    static int id_Available;
    string name;
    int id;
    double balance;
    bool work_status;
    bool health_status;
    double workHour;
    double wagePerHour;
    string type;
    State* state;
protected:
    Staff() {};
    
public:
    Staff(string name); // every staff
    virtual ~Staff() {cout << "Staff dtor" << endl;}
    virtual void work();
    
    virtual string Description(){return "";} // shuqin 
    virtual double Salary() {return workHour * wagePerHour;}
    virtual int getID() { return id; }
    virtual string getName() {return name;}
	virtual void setWorkHour(double hour) { workHour = hour; setBalance(balance + hour*wagePerHour); }
    virtual double Balance() {return balance; }
    virtual void setBalance(double balance) {this->balance = balance;} // add shuqin

    string getType() {return type;}
    virtual string getInfo();
    
    // context
    void changeState(State* state);
    void callingIll();
    virtual void goodMeeting() {}
    virtual void goodWorking() {}
protected:
    void randHealthStatus(int p = 0.15);
    
};

class Cleaner: public Staff {
protected:
    double wagePerHour = 2;
    double workHour = 0;
    
protected:
    Cleaner() {};
public:
    Cleaner(string name);
    virtual ~Cleaner() {cout <<"Cleaner dtor" << endl;}
    virtual string Description() {return "Cleaner:";} // a description of this cleaner's duty
    
    void goodMeeting();
    virtual void goodWorking();
    
};
class Feeder: public Staff {
protected:
    double wagePerHour = 1.5;
    double workHour = 0;
protected:
    Feeder() {};
public:
    Feeder(string name);
    virtual ~Feeder() {cout <<"Feeder dtor" << endl;}
    virtual string Description() {return "Feeder: ";}
    void goodMeeting();
    void goodWorking(){}
};

class Vetaritarian: public Staff {
    
public:
    Vetaritarian(string name);
    
    string Description() {return "Vetaritarian";}
    void goodMeeting();
    virtual void goodWorking() {} // not determined
    
};

class Salesman: public Staff {
public:
    Salesman(string name);
    
    string Description() {return "Salesman";}
    void goodMeeting();
    virtual void goodWorking(){}
};
#endif


