#ifndef Food_hpp
#define Food_hpp


#include <iostream>
#include <vector>

using namespace std;
enum FoodType//feed types
{
    forCattle, forSheep, forChicken, forDuck, forFish, forPig, forDog
};


class Food
{
public:
    static void addPrototype(Food* feed){prototypes[nextSlot++] = feed;}
    static Food* find_add_one(FoodType type);//add one feed with a specific type to the container
    static void find_reduce_one(FoodType type);//reduce one feed with a specific type
    static int getCount(FoodType type);//get the count of a feed with a specific  type
    virtual int returnCount()=0;
    virtual ~Food(){cout <<"Feed dtor"<<endl;}
    
protected:
    virtual FoodType returnType()=0;
    virtual Food* clone()=0;
    virtual void Delete()=0;//change the value of 'count'
private:
    static Food* prototypes[10];//store all the created prototype here
    static int nextSlot;//the next slot's subscript in 'prototype[]'
    
    static vector<Food*> foods;
};
#endif /* Food_hpp */
