#pragma once
#include <iostream>
#include "Animal.h"
using namespace std;


template <class Item>
class Iterator
{
public:
	virtual void first() = 0;
	virtual void next() = 0;
	virtual Item* currentItem() = 0;
	virtual bool isDone() = 0;
	virtual ~Iterator(){}
};

template<class Animal>
class ConcreteIterator : public Iterator<Animal>
{
private:
	Animal* _aggr;
	int _cur;
public:
	ConcreteIterator(Animal* a): _aggr(a), _cur(0){}
	virtual void first()
	{
		_cur = 0;
	}
	virtual void next()
	{
		if (_cur < _aggr->getChild())
			_cur++;
	}
	virtual Animal* currentItem()
	{
		return _aggr->Pop(_cur);
	}
	virtual bool isDone()
	{
		return (_cur >= _aggr->getChild());
	}
};