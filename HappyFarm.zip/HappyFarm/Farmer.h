#ifndef Farmer_h
#define Farmer_h


#include<iostream>
#include<string>
#include<cstdio>
#include "Sales.h"
#include "FarmFactory.h"
#include "Department.h"
using namespace std;

//Singleton pattern
class Farmer      //The Farmer class
{
	public:
    
        // MARK: Static method
		static Farmer* getInstance(string farmer_name, string farm_name);     //Instantiate the object and return the object.
        static Farmer* getInstance();
		static void cleanInstance(); //Clear the instance.
    
		void Hire(string type, string name);
		void Dismiss(string type, int staff_id); //Dismiss staff
		void DisplayStaff(string type); //Hire staff
	    void PaySalary(int staff_id);  //The farmer pays for the staff's salary.
	    void OpenFarm();                                                     //The farmer opens the farm.
	    void CloseFarm(); //The farmer closes the farm.
    
        string farmer_name,farm_name;
	    bool farm_status; //The farm's status.
		static Cleaning* cleaning; //The pointer of cleaning department
		static Feeding* feeding; //The pointer of feeding department
		static Sales* sales; //The pointer of sales department
		static Hospital* hospital; //The pointer of hospital department
		static FarmFactory* farm;  //The instance of farm factory


	private:
		Farmer()  { }                                                   
	    Farmer(string farmer_name, string farm_name)
	    {
		    this->farmer_name = farmer_name;
            this->farm_name = farm_name;
		}
        ~Farmer() {};
	    static Farmer* uniquefarmer;                                     //The Farmer class's unique instance.
};

#endif /* Farmer_h */
