#ifndef FarmFactory_h
#define FarmFactory_h
#include<iostream>
#include<cstdio>
#include<string>
#include"Staff.h"


using namespace std;

class FarmFactory
{
public:
	FarmFactory() {};
	void createStaff(string type, string name);
	void removeStaff(string type, int staff_id);
	void showStaff(string type);
    
    Staff* findStaff(int id);
};

#endif /* FarmFactory_h */
