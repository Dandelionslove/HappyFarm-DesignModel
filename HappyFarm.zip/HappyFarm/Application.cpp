//#include"Environment.h"
#include"FlowerBuilder.h"
#include "EnvironmentManager.h"
#include "Farmer.h"
#include "Animal.h"
#include "Type.h"
#include "Businessman.h"
#include "FeederDecorator.h"
#include "CleanerDecorator.h"
#include<string>

void show_instrucitons();
void show_initial_farm();
void CommandPatterTest();
void BuilderPatternTest();
void TraverseList(Animal* animal);
FoodType foodAcc(int type);
void Strategy_Iterator_Composition_Template_Proxy_PatternTest();
void AnimalProxy(int i, string ss, string s);
void ObserverPatternTest();
void templateMethodAndDecoratorTest();
void Factory_Singleton_Template_PatternTest();


int main()
{
	show_initial_farm();
	show_instrucitons();
	int ch1;
	cin >> ch1;     
	while (0!=ch1)               //Select the identity
	{
        
		switch (ch1)
		{
		case 1:       /* Command Pattern: As a Environment manager */
		{
            CommandPatterTest();
			break;
		}
		case 2:     /*  Builder Pattern: As a gardener   */
		{
            BuilderPatternTest();
			break;
		}
		case 3: /* manage animals*/
		{
			Strategy_Iterator_Composition_Template_Proxy_PatternTest();
			break;
		}
        case 4: /* Factory method, singleton, template method : hire and dismiss staffs */
        {
			Factory_Singleton_Template_PatternTest();
			break;
        } 
		
		case 5: /* templateMethod_And_Decorator Patterns */
		{
			templateMethodAndDecoratorTest();
			break;
        }
		case 6:/* Observer Pattern */
		{
			ObserverPatternTest();
			break;
		}
		case 0:      //Exit the farm
		{
			break;
		}
		default:
		{
			cout << "\nWrong command!\n";
			break;
		}
		}
        if (ch1 == 0) {
            break;
        } else {
            show_instrucitons();
        }
		cin.clear();
		cin >> ch1;
	}
	cout << "You have already exited our Happy Farm!"
		<< endl;
	

	system("pause");
	return 1;
}
void show_instrucitons()
{
    cout << " - - - - - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
	cout << "\nInput 1 to be as a Environment manager."
		<<"\nInput 2 to be as a gardener."
		<< "\nInput 3 to  manage animals"
        <<"\nInput 4 to be as a farmer to hire or dismiss staffs"
        <<"\nInput 5 to be as a farmer to assign work to staffs"
		<<"\nInput 6 to be as a doctor to observe the farm"
		<< "\nInput 0 to exit the farm system.\n";
    cout << " - - - - - - - - - - - - - - - - - - - - - - - - - - - -" << endl;

    cout << "\nNow please input your command:\t";
}
void show_initial_farm()
{
	cout << "***************    Happy Farm    **************" << endl;
    cout << "\nWelcome to our happy farm." << endl;
    cout << "Operating specification: " << endl;
    cout << "By entering the role you want to operate on, you can then choose what job you wanna perform. Between each operation, there is a background time going at 2 hours pace." << endl;
    cout << "Enjoy exploring!" << endl;
		
}

void CommandPatterTest()
{
    EnvironmentManager *enManager = new EnvironmentManager();
    int ch2;
    cout << "\nNow you can do th following commands:\n"
    << "Press 1:\t to reset the temperature\n"
    << "Press 2:\t to reset the humidity level\n"
    << "Press 3:\t to reset the illumination level\n"
    << "Press 0:\t to exit the manager model\n\n"
    << "Now please input your command:\t";
    cin >> ch2;
    int set_value = 0;
    while (0 != ch2)             //Select the commands
    {
        switch (ch2)
        {
            case 1:
            {
                cout << "Please input the temperature value you want to set:\t";
                cin >> set_value;
                enManager->set_tem(set_value);
                cout << "\nPlease input your next command:\t";
                break;
            }
            case 2:
            {
                cout << "Please input the humility level you want to set:\t";
                cin >> set_value;
                enManager->set_humi(set_value);
                cout << "\nPlease input your next command:\t";
                break;
            }
            case 3:
            {
                cout << "Please input the illumination level you want to set:\t";
                cin >> set_value;
                enManager->set_illu(set_value);
                cout << "\nPlease input your next command:\t";
                break;
            }
            case 0:
            {
                break;
            }
            default:
            {
                cout << "\nWrong command!\n"
                << "\nPlease input your command again:\t";
                break;
            }
        }
        cin >> ch2;
    }
    cout << "\nYou have already exited the Environment manager model.\n";
    
}
void BuilderPatternTest()
{
    int ch2;
    Gardener gardener;
    cout << "\nNow you can do the following commands:"
    << "\nPress 1:\tto plant a rose"
    << "\nPress 2:\tto plant a dandelion"
    << "\nPress 0:\tto exit the gardener model\n\n"
    << "Now please input your command:\t";
    cin >> ch2;
    while (0 != ch2)
    {
        switch (ch2)
        {
            case 1:
            {
                FlowerBuilder *roseBuilder = new RoseBuilder();
                gardener.setFlowerBuilder(roseBuilder);
                gardener.plantFlower();
                Flower *flower = gardener.getFlower();
                cout << "Plant a rose successfully!\n";
                cout << "\nPlease input your next command:\t";
                break;
            }
            case 2:
            {
                FlowerBuilder *dandelionBuilder = new DandelionBuilder();
                gardener.setFlowerBuilder(dandelionBuilder);
                gardener.plantFlower();
                Flower *flower = gardener.getFlower();
                cout << "Plant a dandelion successfully!\n";
                cout << "\nPlease input your next command:\t";
                break;
            }
            case 0:
            {
                break;
            }
            default:
            {
                cout << "\nWrong command!\n"
                << "\nPlease input your command again:\t";
                break;
            }
        }
        cin >> ch2;
    }
    cout << "\nYou have already exited the gardener model.\n";
}

void TraverseList(Animal* animal)
{
	Iterator<Animal>* iter = animal->createIterator();
	while (!iter->isDone())
	{
		cout << iter->currentItem()->getName() << "; ";
		TraverseList(iter->currentItem());
		iter->next();
	}
	return;
}


FoodType foodAcc(int type) {
	//1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG
	switch (type) {
	case 1:
		return forSheep;
	case 2:
		return forCattle;
	case 3:
		return forChicken;
	case 4:
		return forDuck;
	case 5:
		return forFish;
	case 6:
		return forPig;
	case 7:
		return forDog;

	default:
		return forSheep;

	}
}

void Strategy_Iterator_Composition_Template_Proxy_PatternTest()
{
	cout << "Enter choice: "
		<< "\n0. Exit\n1. Add animal"
		<< "\n2. Interesting Animal strategy"
		<< "\n3. Composite Animal Family(Get Children of an Animal)"
		<< "\n4. born child"
		<< "\n5. Template method"
		<< "\n6. Sale Annimal"
		<< "\n7. Count Animals"
		<< "\n8. Animal morning exercise\n\n"
		<< "Now please input your command:\t";
	int ch2;
	cin >> ch2;
	while (ch2 != 0)
	{
		cout << "Enter animal type: \n"
			<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;
		switch (ch2) {
		case 1: {
			/*cout << "Enter animal type: \n"
			<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;*/
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Give your animal a name: ";
				string ch3;
				cin >> ch3;
				cout << "Enter sex: 1. MALE, 2. FEMALE" << endl;
				int sex;
				cin >> sex;
				Farmer::sales->addAnimal(SpeciesType(ch2), ch3, SexType(sex));

			}
			break;
		}
		case 2:
		{
			/*cout << "Enter animal type: \n"
			<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;*/
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Enter animal name: ";
				string ch3;
				cin >> ch3;
				Animal* a = Farmer::sales->findAnimal(SpeciesType(ch2), ch3);
				if (a == NULL) {
					cout << "Could not find one " << endl;
					break;
				}
				cout << "Enter animal state: 1. HUNGRY, 2. HAPPY, 3. SAD\n";
				int state;
				cin >> state;
				if (state < 4 && state > 0) {
					a->setCallStrategy(ch2, state);
					a->doCall();
				}
			}
			else {
				cout << "Invalid input" << endl;
			}
			break;
		}
		case 3: 
		{
			/*cout << "Enter animal type: \n"
			<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;*/
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Enter animal name: ";
				string ch3;
				cin >> ch3;

				Animal * a = Farmer::sales->findAnimal(SpeciesType(ch2), ch3);
				if (a == NULL) {
					cout << "Could not find one " << endl;
					break;
				}
				if (a->getChild() == 0)
				{
					cout << a->Species() << ": " << a->getName() << ": " << a->getSex() << ": No Child." << endl;   //getChild to find how many child this sheep has
					break;
				}
				cout << a->Species() << ": " << a->getName() << ": " << a->getSex() << ": " << a->getChild() << " Children." << endl;   //getChild to find how many child this sheep has
				cout << "Chileren's Names: ";
				TraverseList(a);
				cout << endl;
			}
			else {
				cout << "Invalid input" << endl;
			}
			break;
		}

		case 4: 
		{ // born
				  /*cout << "Enter animal type: \n"
				  << "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;*/
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Enter animal name: ";
				string ch3;
				cin >> ch3;

				Animal * a = Farmer::sales->findAnimal(SpeciesType(ch2), ch3);
				if (a == NULL) {
					cout << "Could not find one " << endl;
					break;
				}
				a->BornChild();
			}
			else {
				cout << "Invalid input" << endl;
			}
			break;
		}
		case 5: 
		{
			/*cout << "Enter animal type: \n"
			<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;*/
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Enter animal name: ";
				string ch3;
				cin >> ch3;

				Animal * a = Farmer::sales->findAnimal(SpeciesType(ch2), ch3);
				if (a == NULL) {
					cout << "Could not find one " << endl;
					break;
				}
				cout << "Call eat template method: ";

				a->Eat(foodAcc(ch2));
			}
			else {
				cout << "Invalid input" << endl;
			}
			break;
		}
		case 6: 
		{
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Enter animal name: ";
				string ch3;
				cin >> ch3;
				Animal* a = Farmer::sales->removeAnimal(SpeciesType(ch2), ch3);
				if (a == NULL)
				{
					cout << "Failed to Sale.\n";
					break;
				}
				cout << a->Species() << ": " << a->getName() << ": " << a->getSex() << ": " << "Saled!\n";
			}
			else {
				cout << "Invalid input" << endl;
			}
			break;
		}
		case 7: 
		{
			cout << endl;
			AnimalNum::ShowAnimals();
			break;
		}
		case 8: 
		{
			/*cout << "Enter animal type: \n"
			<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;*/
			cin >> ch2;
			if (ch2 < 8 && ch2 > 0) {
				cout << "Enter animal name: ";
				string ch3;
				cin >> ch3;
				Animal * a = Farmer::sales->findAnimal(SpeciesType(ch2), ch3);
				if (a == NULL) {
					cout << "Could not find one " << endl;
					break;
				}
				else {
					cout << "Do moring excecise: ";
					string name = a->getName();
					string sex = a->getSex();
					AnimalProxy(ch2, name, sex);
				}
			}
			else {
				cout << "Invalid input" << endl;
			}
			break;
		}
		default:
		{
			break;
		}
		}
		cout << "\nEnter choice: "
			<< "\n0. Exit\n1. Add animal"
			<< "\n2. Interesting Animal strategy"
			<< "\n3. Composite Animal Family(Get Children of an Animal)"
			<< "\n4. born child"
			<< "\n5. Template method"
			<< "\n6. Sale Annimal"
			<< "\n7. Count Animals\n\n"
			<< "Now please input your command:\t";
		cin >> ch2;
	}
}
void Factory_Singleton_Template_PatternTest() {
	cout << "Enter choice: "
		<< "\n0. Exit\n1. Hiring"
		<< "\n2. Dismiss"
		<< "\n3. Display Staffs"
		<< "\n4. Pay salary"
		<< "\n5. Open farm"
		<< "\n6. Close farm\n\n" << "Now please input your command:\t";
	int ch2;
	cin >> ch2;
	switch (ch2) {
	case 0:
		break;
	case 1: {
		string names[5] = { "0" , "sales", "feeding", "cleaning", "hospital" };
		cout << "What type of staff do you want?" << endl;
		cout << "1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			cout << "Enter staff name: ";
			string name;
			cin >> name;
			Farmer::getInstance()->Hire(names[ch3], name);
		}
		else {
			cout << "invalid input" << endl;
		}
		break;
	}
			break;
	case 2: {
		string names[5] = { "0" , "sales", "feeding", "cleaning", "hospital" };
		cout << "What type of staff do you want?" << endl;
		cout << "1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			cout << "Enter staff id: ";
			int id;
			cin >> id;
			Farmer::getInstance()->Dismiss(names[ch3], id);
		}
		else {
			cout << "invalid input" << endl;
		}
		break;
	}
			break;
	case 3: {
		string names[5] = { "0" , "sales", "feeding", "cleaning", "hospital" };
		cout << "What type of staff do you want?" << endl;
		cout << "0. all 1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			Farmer::getInstance()->DisplayStaff(names[ch3]);

		}
		else {
			Farmer::getInstance()->DisplayStaff("all");
		}
		break;
	}
	case 4: {
		cout << "Enter staff id: ";
		int id;
		cin >> id;
		Farmer::getInstance()->PaySalary(id);
		break;
	}
			break;
	case 5: {
		Farmer::getInstance()->OpenFarm();
		break;
	}
	case 6: {
		Farmer::getInstance()->CloseFarm();
		break;
	}

	default:
		break;
	}
}
/*add proxy funcation zxy*/
void AnimalProxy(int i, string ss, string s) {
	cout << "This is a wonderful morning !\n";
	if (i == 1)
	{
		//create proxy of sheep
		//When you call this function, the sheep will really do the morning exercise
		ProxySheep sheep;
		sheep.doExercise(ss, s);

	}
	if (i == 2)
	{
		//create proxy of cattle
		//When you call this function, the cattle will really do the morning exercise
		ProxyCattle cattle;
		cattle.doExercise(ss, s);
	}
	if (i == 3)
	{
		//create proxy of chicken
		//When you call this function, the chicken will really do the morning exercise
		ProxyChicken chick;
		chick.doExercise(ss, s);
	}
	if (i == 4)
	{
		//create proxy of duck
		//When you call this function, the duck will really do the morning exercise
		ProxyDuck duck;
		duck.doExercise(ss, s);
	}
	if (i == 5)
	{

		//create proxy of fish
		//When you call this function, the fish will really do the morning exercise
		ProxyFish fish;
		fish.doExercise(ss, s);
	}
	if (i == 6)
	{
		//create proxy of pig
		//When you call this function, the pig will really do the morning exercise
		ProxyPig pig;
		pig.doExercise(ss, s);
	}
	if (i == 7)
	{
		//create proxy of dog
		//When you call this function, the dog will really do the morning exercise
		ProxyDog dog;
		dog.doExercise(ss, s);
	}
}
void ObserverPatternTest() {

    Farmer* pSingleton1 = Farmer::getInstance();
    
    pSingleton1->Hire("feeding", "Tom");
    pSingleton1->Hire("feeding", "Mary");
    pSingleton1->Hire("cleaning", "Bob");
    pSingleton1->Hire("cleaning", "Lary");
    pSingleton1->Hire("sales", "Hary");
    pSingleton1->Hire("sales", "Dan");
    pSingleton1->Hire("hospital", "Vivin");
    pSingleton1->Hire("hospital", "Lucy");
    
    pSingleton1->sales->addCustomer(new Businessman("Angela", "18201966772"));
    pSingleton1->sales->addCustomer(new Businessman("Lucy", "18201966771"));
    pSingleton1->sales->addCustomer(new Businessman("Serina", "18201966770"));
    
    
    AnimalList<Sheep> sheepList;
    sheepList.addAnimal(SHEEP, "A", FEMALE);
    Sheep* sheep = new Sheep(SHEEP, "B", MALE);
    sheepList.addAnimal(sheep);
    
    AnimalList<Cattle> cattleList;
    cattleList.addAnimal(CATTLE, "cattle1", MALE);
    cattleList.addAnimal(CATTLE, "cattle2", MALE);
    cattleList.addAnimal(CATTLE, "cattle3", MALE);
    
    AnimalList<Duck> duckList;
    duckList.addAnimal(DUCK, "duck1", MALE);
    duckList.addAnimal(DUCK, "duck2", MALE);
    duckList.addAnimal(DUCK, "duck3", MALE);
    
    
    
    int ch2;
    cout << "\nThe farm has already hired some workers for every department and Sales Department owns some customers.\n"
    << "Meanwhile there are some animals in the farm."
    << "you can do the following things to test Observer Pattern: \n"
    << "Press 1:\t to notify Cleaning Department's employee to have a meeting\n"
    << "Press 2:\t to notify Feeding Department's employee to have a meeting\n"
    << "Press 3:\t to notify Hospital Department's employee to have a meeting\n"
    << "Press 4:\t to remind Sales Department's customers to check the latest supply list\n"
    << "Press 0:\t to exit\n"
    << "Now please input your choice:\t";
    cin >> ch2;
    while (0 != ch2) {
        switch (ch2)
        {
            case 1:
            {
                pSingleton1->cleaning->notifyMeeting();
                break;
            }
            case 2:
            {
                pSingleton1->feeding->notifyMeeting();
                break;
            }
            case 3:
            {
                pSingleton1->hospital->notifyMeeting();
                break;
            }
            case 4:
            {
                 pSingleton1->sales->supplyListChanged();
                break;
            }
            case 0:
            {
                return;
            }
            default:
            {
                cout << "wrong input";
                break;
            }
        }
        cin >> ch2;
    }
    
}

void templateMethodAndDecoratorTest() { // add shuqin

	cout << "Enter choice: "
		<< "\n0. exit"
		<< "\n1. Assign work\n\n"
		<< "Now please input your command:\t";
	int ch2;
	cin >> ch2;
	cout << "Enter choice: "
		<< "\n0. Exit\n1. On cleaner"
		<< "\n2. On feeder"
		<< "\n3. On veteritarian"
		<< "\n4. On salesman\n\n"
		<< "Now please input your command:\t";
	int ch3;
	cin >> ch3;

	switch (ch2) {
		/*case 1:
		switch (ch3) {
		case 1:
		Farmer::getInstance()->cleaning->notifyMeeting();
		break;
		case 2:
		Farmer::getInstance()->feeding->notifyMeeting();
		break;
		case 3:
		Farmer::getInstance()->hospital->notifyMeeting();
		break;
		case 4:
		Farmer::getInstance()->sales->notifyMeeting();
		break;
		default:
		break;
		}
		break;*/
	case 1:
	{
		Staff* s;
		int ch4;
		switch (ch3) {
		case 1:
			cout << "Please enter farmer id: ";
			cin >> ch3;
			s = Farmer::getInstance()->cleaning->assignJob(ch3);
			if (s == NULL)
				break;
			cout << "What specific work would you like him/her to do? \n"
				<< "1. To clean domestic animals, 2. To clean poultry animals" << endl;

			cin >> ch4;
			switch (ch4) {
			case 1:
				s = new DomesticCleanerDecorator(static_cast<Cleaner*>(s));
				cout << "Set " << s->getInfo() << "to clean domestic animals successfully." << endl;
				break;
			case 2:
				s = new PoultryCleanerDecorator(static_cast<Cleaner*>(s));
				cout << "Set " << s->getInfo() << "to clean poultry animals successfully." << endl;

			default:
				cout << "Invalid input, set this staff do no specific work" << endl;
				break;
			}

			break;
		case 2:
			cout << "Please enter feeder id: ";
			cin >> ch3;
			s = Farmer::getInstance()->feeding->assignJob(ch3);
			if (s == NULL)
				break;
			cout << "What specific work would you like him/her to do? \n"
				<< "1. feed sheep, 2. feed fish 3. feed cattle \n4. feed duck 5. feed dog 6. feed chicken 7. feed pig" << endl;

			cin >> ch4;
			switch (ch4) {
			case 1:
				s = new SheepFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed sheeps successfully." << endl;
				break;
			case 2:
				s = new FishFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed fishes successfully." << endl;
			case 3:
				s = new CattleFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed cattles successfully." << endl;
			case 4:
				s = new DuckFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed ducks successfully." << endl;
			case 5:
				s = new DogFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed dogs successfully." << endl;
			case 6:
				s = new ChickenFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed chickens successfully." << endl;
			case 7:
				s = new PigFeederDecorator(static_cast<Feeder*>(s));
				cout << "Set " << s->getInfo() << "to feed pigs successfully." << endl;

			default:
				cout << "Invalid input, set this staff do no specific work" << endl;
				break;
			}
			break;
		case 3:
			cout << "Please enter veteritarian id: ";
			cin >> ch3;
			Farmer::getInstance()->hospital->assignJob(ch3);
			break;
		case 4:
			cout << "Please enter farmer id: ";
			cin >> ch3;
			Farmer::getInstance()->sales->assignJob(ch3);
			break;
		default:
			break;
		}
		break;
	}


	default:
		break;
	}

}