#pragma once
//Enum of Animal type
enum SpeciesType
{
	SHEEP = 1, CATTLE, CHICKEN, DUCK, FISH, PIG, DOG
};
//Enum of Animal sex
enum SexType
{
	MALE = 1, FEMALE
};
//Enum of Animal state
enum AnimalState
{
	HUNGRY = 1, HAPPY, SAD
};
