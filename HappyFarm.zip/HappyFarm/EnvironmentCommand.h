#pragma once
#include<iostream>
#include<stdlib.h>

using namespace std;
//////////////Design Model:  Command
class Environment
{
public:
	Environment()       //default ctor
	{
		temperature = 27;
		humidity_level = 3;
		illumination_level = 5;
		cout << "Enviroment:ctor: Enviroment initialed!\n";
		cout << "The enviroment in the farm now:\n"
			<< "Temperature:\t27C`\n"
			<< "Humidity level:\t3\n"
			<< "Illumination level:\t5\n";
	}
	void set_tem(int tem_value)
	{
		if (tem_value < 5)
		{
			cout << "\nEnvironment:set_tem:Sorry, the temperature being setted is too low!\nThe temperature is still " << temperature << endl;
			return;
		}
		if (tem_value > 40)
		{
			cout<<"\nEnvironment:set_tem:Sorry, the temperature being setted is too high!\nThe temperature is still " << temperature << endl;
			return;
		}
		this->temperature = tem_value;
		cout << "\nEnvironment:set_tem:Set successfully!\nThe temperature in the farm now is " << temperature;
		cout << endl;
		return;

	}
	void set_humi(int humi_level)
	{
		if (humi_level <= 0)
		{
			cout << "\nEnvironment:set_humi:Sorry!The humility level besing setted is too low!\n"
				<< "The humility level is still " << humidity_level << '\n';
			return;
		}
		if (humi_level > 10)
		{
			cout<< "\nEnvironment:set_humi:Sorry!The humility level besing setted is too high!\n"
				<< "The humility level is still " << humidity_level << endl;
			return;
		}
		this->humidity_level = humi_level;
		cout << "\nEnvironment:set_humi:Set successfully!\nThe humidity level in the farm now is " << humidity_level<<"\n";
		return;

	}
	void set_illu(int illu_level)
	{
		if (illu_level <= 0)
		{
			cout << "\nEnvironment:set_illu:Sorry!The illumination level besing setted is too low!\n"
				<< "The illumination level is still " << illumination_level << endl;
			return;
		}
		if (illu_level >10)
		{
			cout << "\nEnvironment:set_illu:Sorry!The illumination level besing setted is too high!\n"
				<< "The illumination level is still " << illumination_level << endl;
			return;
		}
		this->illumination_level = illu_level;
		cout << "\nEnvironment:set_illu:Set successfully!\nThe illumination level in the farm now is " << illumination_level;
		cout << endl;
		return;
	}
private:
	int temperature;
	int humidity_level;//using level to describe the humidity.The bigger the value,the higher the humidity level.
	int illumination_level;//using level to dscribe the illuminaton---The same as the humidity
};

class Command
{
public:
	typedef void(Environment::*Action)(int set_value);
	Command(Environment* object, Action method)    //ctor
	{
		e_object = object;
		e_method = method;
	}
	void execute(int set_value)
	{
		(e_object->*e_method)(set_value);
	}
private:
	Environment* e_object;
	Action e_method;
};

