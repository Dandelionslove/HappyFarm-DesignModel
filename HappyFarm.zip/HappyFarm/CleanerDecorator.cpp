#include "CleanerDecorator.h"

DomesticCleanerDecorator::DomesticCleanerDecorator(Cleaner* cleaner): CleanerDecorator(cleaner) {
    type = "Domestic";
}

PoultryCleanerDecorator :: ~PoultryCleanerDecorator() {
    delete pCleaner;
    cout << "PoultryCleanerDecorator dtor" << endl;
}
PoultryCleanerDecorator::PoultryCleanerDecorator(Cleaner* cleaner): CleanerDecorator(cleaner) {
    type = "Poultry";
}