#include"FlowerBuilder.h"
#include "EnvironmentManager.h"
#include "Farmer.h"
#include "Animal.h"
#include "Type.h"
#include "Businessman.h"
#include "FeederDecorator.h"
#include "CleanerDecorator.h"
#include<string>


void InitialAnimalList();
void TraverseList(Animal* animal);
FoodType foodAcc(int type);

void AnimalProxy(int i, string ss, string s);// add by zxy

void Proxy_Pattern_test();/* 1 */
void Factory_Pattern_test();/* 2 */
void Singleton_Pattern_test();/* 3 */
void Observer_Pattern_test();/* 4 */
void Prototype_Pattern_test();/* 5 */
void Strategy_Pattern_test();/* 6 */
void Iterator_Pattern_test();/* 7 */
void Composite_Pattern_test();/* 8 */
void Template_Method_Pattern_test();/* 9 */
void Decorator_Pattern_test();/* 10 */
void Delegate_Pattern_test();/* 11 */
void Command_Pattern_test();/* 12 */
void Builder_Pattern_test();/* 13 */
void State_Pattern_test();/* 14 */

int main()
{
	//Add by LY
	/* Begin */
	InitialAnimalList();
	bool animalIntialed = false;
	/* End */

	cout << "******Now you can choose a pattern to start your pattern test*******.\n"
		<< "press 1:\tProxy Pattern test\n"
		<< "press 2:\tFactory Pattern test\n"
		<< "press 3:\tSingleton Pattern test\n"
		<< "press 4:\tObserver Pattern test\n"
		<< "press 5:\tPrototype Pattern test\n"
		<< "press 6:\tStrategy Pattern test\n"
		<< "press 7:\tIterator Pattern test\n"
		<< "press 8:\tComposite Pattern test\n"
		<< "press 9:\tTemplate Method Pattern test\n"
		<< "press 10:\tDecorator Pattern test\n"
		<< "press 11:\tDelegate Pattern test\n"
		<< "press 12:\tCommand Pattern test\n"
		<< "press 13:\tBuilder Pattern test\n"
		<< "press 14:\tState Pattern test\n"
		<< "press 0:\tExit\n";
	cout << "Please input your choice:\t";

	int pattern_choice;
	cin >> pattern_choice;
	while (0 != pattern_choice)
	{
		switch (pattern_choice)
		{
		case 0:/* Exit */
		{
			cout << "Exit successfully!\n";
			break;
		}
		case 1:/* Proxy Pattern */
		{
			Proxy_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 2:/* Factory Pattern */
		{
			Factory_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 3:/* Singleton Pattern */
		{
			Singleton_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 4:/* Observer Pattern */
		{
			Observer_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 5:/* Prototype Pattern */
		{
			Prototype_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 6:/* Strategy Pattern */
		{
			if (!animalIntialed)
			{
				InitialAnimalList();
				animalIntialed = true;
			}
			Strategy_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 7:/* Iterator Pattern */
		{
			if (!animalIntialed)
			{
				InitialAnimalList();
				animalIntialed = true;
			}
			Iterator_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 8:/* Composite Pattern */
		{
			if (!animalIntialed)
			{
				InitialAnimalList();
				animalIntialed = true;
			}
			Composite_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 9:/* Template Method */
		{
			if (!animalIntialed)
			{
				InitialAnimalList();
				animalIntialed = true;
			}
			Template_Method_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 10:/* Decorator Pattern */
		{
			Decorator_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 11:/* Delegate Pattern */
		{
			Delegate_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 12:/* Command Pattern */
		{
			Command_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 13:/* Builder Pattern */
		{
			Builder_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		case 14:/* State Pattern */
		{
			State_Pattern_test();
			cout << "Please input your next choice:\t";
			break;
		}
		default:/* Invalid choice */
		{
			cout << "Please input your next choice:\t";
			break;
		}
		}
		if (0 == pattern_choice)break;
		cin >> pattern_choice;
	}

	system("pause");
	return 0;
}

void Proxy_Pattern_test()
{
	int ch1 = 0;
	cout << "You should create a animal first\n ";
	cout << "Enter animal type: \n"
		<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;
	cin >> ch1;
	if (ch1 < 8 && ch1 > 0) {
		cout << "You should create a animal first .Give your animal a name: ";
		string ch3;
		cin >> ch3;
		cout << "Enter sex: 1. MALE, 2. FEMALE" << endl;
		int sex;
		cin >> sex;
		Farmer::sales->addAnimal(SpeciesType(ch1), ch3, SexType(sex));
	}
	else {
		cout << "Invalid input" << endl;
	}
	cout << "\nEnter the name of the animal which you want it to do morning exercise: ";
	string ch3;
	cin >> ch3;
	Animal * a = Farmer::sales->findAnimal(SpeciesType(ch1), ch3);
	if (a == NULL) {
		cout << "Could not find one " << endl;
	}
	else {
		cout << "Do moring excecise: ";
		string name = a->getName();
		string sex = a->getSex();
		AnimalProxy(ch1, name, sex);
	}
}
void Factory_Pattern_test()
{
	cout << "Enter choice: "
		<< "\n0. Exit\n1. Hiring"
		<< "\n2. Dismiss"
		<< "\n3. Display Staffs"
		<< "\n4. Pay salary"
		<< "\n5. Open farm"
		<< "\n6. Close farm\n\n" << "Now please input your command:\t";
	int ch2;
	cin >> ch2;
	switch (ch2) {
	case 0:
		break;
	case 1: {
		string names[5] = { "0" , "salesman", "feeder", "cleaner", "veterinarian" };
		cout << "What type of staff do you want?" << endl;
		cout << "1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			cout << "Enter staff name: ";
			string name;
			cin >> name;
			Farmer::getInstance()->Hire(names[ch3], name);
		}
		else {
			cout << "invalid input" << endl;
		}
		break;
	}
	case 2: {
		string names[5] = { "0" , "salesman", "feeder", "cleaner", "veterinarian" };
		cout << "What type of staff do you want?" << endl;
		cout << "1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			cout << "Enter staff id: ";
			int id;
			cin >> id;
			Farmer::getInstance()->Dismiss(names[ch3], id);
		}
		else {
			cout << "invalid input" << endl;
		}
		break;
	}
	case 3: {
		string names[5] = { "0" , "salesman", "feeder", "cleaner", "veterinarian" };
		cout << "What type of staff do you want?" << endl;
		cout << "0. all 1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			Farmer::getInstance()->DisplayStaff(names[ch3]);

		}
		else {
			Farmer::getInstance()->DisplayStaff("all");
		}
		break;
	}
	case 4: {
		cout << "Enter staff id: ";
		int id;
		cin >> id;
		Farmer::getInstance()->PaySalary(id);
		break;
	}
	case 5: {
		Farmer::getInstance()->OpenFarm();
		break;
	}
	case 6: {
		Farmer::getInstance()->CloseFarm();
		break;
	}

	default:
		break;
	}
}
void Singleton_Pattern_test()
{
	cout << "Enter choice: "
		<< "\n0. Exit\n1. Hiring"
		<< "\n2. Dismiss"
		<< "\n3. Display Staffs"
		<< "\n4. Pay salary"
		<< "\n5. Open farm"
		<< "\n6. Close farm\n\n" << "Now please input your command:\t";
	int ch2;
	cin >> ch2;
	switch (ch2) {
	case 0:
		break;
	case 1: {
		string names[5] = { "0" , "salesman", "feeder", "cleaner", "veterinarian" };
		cout << "What type of staff do you want?" << endl;
		cout << "1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			cout << "Enter staff name: ";
			string name;
			cin >> name;
			Farmer::getInstance()->Hire(names[ch3], name);
		}
		else {
			cout << "invalid input" << endl;
		}
		break;
	}
	case 2: {
		string names[5] = { "0" , "salesman", "feeder", "cleaner", "veterinarian" };
		cout << "What type of staff do you want?" << endl;
		cout << "1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			cout << "Enter staff id: ";
			int id;
			cin >> id;
			Farmer::getInstance()->Dismiss(names[ch3], id);
		}
		else {
			cout << "invalid input" << endl;
		}
		break;
	}
	case 3: {
		string names[5] = { "0" , "salesman", "feeder", "cleaner", "veterinarian" };
		cout << "What type of staff do you want?" << endl;
		cout << "0. all 1. salesman 2.feeder 3. cleaner 4. veterinarian" << endl;
		int ch3;
		cin >> ch3;
		if (ch3 == 1 || ch3 == 2 || ch3 == 3 || ch3 == 4) {
			Farmer::getInstance()->DisplayStaff(names[ch3]);

		}
		else {
			Farmer::getInstance()->DisplayStaff("all");
		}
		break;
	}
	case 4: {
		cout << "Enter staff id: ";
		int id;
		cin >> id;
		Farmer::getInstance()->PaySalary(id);
		break;
	}
	case 5: {
		Farmer::getInstance()->OpenFarm();
		break;
	}
	case 6: {
		Farmer::getInstance()->CloseFarm();
		break;
	}

	default:
		break;
	}
}
void Observer_Pattern_test()
{
	Farmer* pSingleton1 = Farmer::getInstance();

	pSingleton1->Hire("Feeding", "Tom");
	pSingleton1->Hire("Feeding", "Mary");
	pSingleton1->Hire("Cleaning", "Bob");
	pSingleton1->Hire("Cleaning", "Lary");
	pSingleton1->Hire("Sales", "Hary");
	pSingleton1->Hire("Sales", "Dan");
	pSingleton1->Hire("Hospital", "Vivin");
	pSingleton1->Hire("Hospital", "Lucy");

	pSingleton1->sales->addCustomer(new Businessman("Angela", "18201966772"));
	pSingleton1->sales->addCustomer(new Businessman("Lucy", "18201966771"));
	pSingleton1->sales->addCustomer(new Businessman("Serina", "18201966770"));


	AnimalList<Sheep> sheepList;
	sheepList.addAnimal(SHEEP, "A", FEMALE);
	Sheep* sheep = new Sheep(SHEEP, "B", MALE);
	sheepList.addAnimal(sheep);

	AnimalList<Cattle> cattleList;
	cattleList.addAnimal(CATTLE, "cattle1", MALE);
	cattleList.addAnimal(CATTLE, "cattle2", MALE);
	cattleList.addAnimal(CATTLE, "cattle3", MALE);

	AnimalList<Duck> duckList;
	duckList.addAnimal(DUCK, "duck1", MALE);
	duckList.addAnimal(DUCK, "duck2", MALE);
	duckList.addAnimal(DUCK, "duck3", MALE);



	int ch2;
	cout << "\nThe farm has already hired some workers for every department and Sales Department owns some customers.\n"
		<< "Meanwhile there are some animals in the farm."
		<< "you can do the following things to test Observer Pattern: \n"
		<< "Press 1:\t to notify Cleaning Department's employee to have a meeting\n"
		<< "Press 2:\t to notify Feeding Department's employee to have a meeting\n"
		<< "Press 3:\t to notify Hospital Department's employee to have a meeting\n"
		<< "Press 4:\t to notify Sales Department's employee to have a meeting\n"
		<< "Press 5:\t to remind Sales Department's customers to check the latest supply list\n"
		<< "Now please input your choice:\t";
	cin >> ch2;

	switch (ch2)
	{
	case 1:
	{
		pSingleton1->cleaning->notifyMeeting();
		break;
	}
	case 2:
	{
		pSingleton1->feeding->notifyMeeting();
		break;
	}
	case 3:
	{
		pSingleton1->hospital->notifyMeeting();
		break;
	}
	case 4:
	{
		pSingleton1->sales->notifyMeeting();
	}
	case 5:
	{
		pSingleton1->sales->supplyListChanged();
	}
	default:
	{
		cout << "\nWrong command!\n";
		break;
	}
	}
}
void Prototype_Pattern_test()
{
	cout << "Enter animal name: ";
	string ch3;
	cin >> ch3;

	Animal * a = Farmer::sales->findAnimal(SpeciesType(1), ch3);
	if (a == NULL) {
		cout << "Could not find one " << endl;
	}
	cout << "Call eat template method: ";

	a->Eat(foodAcc(1));
}
void Strategy_Pattern_test()
{
	int type;
	string name;
	cout << "Make Animal call to test strategy pattern.\n";
	cout << "Enter animal type: \n"
		<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;
	cin >> type;
	if (type < 8 && type > 0)
	{
		cout << "Input animal name: ";
		cin >> name;
		Animal* a = Farmer::sales->findAnimal(SpeciesType(type), name);
		if (a == NULL) {
			cout << "No such animal." << endl;
		}
		cout << "Input animal state: 1. HUNGRY, 2. HAPPY, 3. SAD\n";
		int state;
		cin >> state;
		if (state < 4 && state > 0) {
			a->setCallStrategy(type, state);
			a->doCall();
		}
	}
}
void Iterator_Pattern_test()
{
	int type;
	string name;
	cout << "Get children of an animal to test Iterator pattern.\n";
	cout << "Enter animal type: \n"
		<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;
	cin >> type;
	if (type < 8 && type > 0)
	{
		cout << "Input animal name: ";
		cin >> name;
		Animal* a = Farmer::sales->findAnimal(SpeciesType(type), name);
		if (a == NULL) {
			cout << "No such animal." << endl;
		}
		if (a->getChild() == 0)
		{
			cout << a->Species() << ": " << a->getName() << ": " << a->getSex() << ": No Child!\n";
			cout << "Try to choose 8 to let this animal born some children before you do this test.\n";
		}
		else
		{
			cout << "Children Name: ";
			TraverseList(a);
			cout << endl;
		}
		cout << endl;
	}
}
void Composite_Pattern_test()
{
	int type;
	string name;
	cout << "Make animal born children to test composite pattern.\n";
	cout << "Enter animal type: \n"
		<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;
	cin >> type;
	if (type < 8 && type > 0)
	{
		cout << "Input animal name: ";
		cin >> name;
		Animal* a = Farmer::sales->findAnimal(SpeciesType(type), name);
		if (a == NULL) {
			cout << "No such animal." << endl;
		}
		a->BornChild();
		cout << endl;
	}
}
void Template_Method_Pattern_test()
{
	int type;
	string name;
	cout << "Make animal eat food to test template method pattern.\n";
	cout << "Enter animal type: \n"
		<< "1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG" << endl;
	cin >> type;
	if (type < 8 && type > 0)
	{
		cout << "Input animal name: ";
		cin >> name;
		Animal* a = Farmer::sales->findAnimal(SpeciesType(type), name);
		if (a == NULL) {
			cout << "No such animal." << endl;
		}
		a->Eat(foodAcc(type));
		cout << endl;
	}
}
void Decorator_Pattern_test()
{
	// test cleaner decorator
	cout << "\n\n- - - - - - Test cleaner decorator - - - - - -" << endl;
	Cleaner* c = new Cleaner("Cleaner1");
	double hour = 4;
	c->setWorkHour(hour);
	cout << "Raw: cleaner: \n";
	cout << "Description: " << c->Description() << "\n Salary: after do " << hour << " hours' work, shall receive " << c->Salary() << endl;
	cout << "Info: " << c->getInfo() << endl;

	// add decorator
	cout << " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" << endl;
	c = new DomesticCleanerDecorator(c);
	hour = 6;
	c->setWorkHour(hour);
	cout << "After decorated by DomesticCleanerDecorator: \n";
	cout << "Description: " << c->Description() << "\n Salary: after do " << hour << " hours' work, shall receive " << c->Salary() << endl;

	cout << " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" << endl;
	c = new PoultryCleanerDecorator(c);
	hour = 2;
	cout << "After decorated by PoultryCleanerDecorator: \n";
	cout << "Description: " << c->Description() << "\n Salary: after do " << hour << " hours' work, shall receive " << c->Salary() << endl;
	cout << "Info: " << c->getInfo() << "Note that ID is not changed." << endl;

	// test feed decorator
	cout << "\n\n- - - - - - Test feeder decorator - - - - - -" << endl;

	Feeder* f = new Feeder("Feeder");
	hour = 4;
	f->setWorkHour(hour);
	cout << "Raw: feeder: \n";
	cout << "Description: " << f->Description() << "\n Salary: after do " << hour << " hours' work, shall receive " << f->Salary() << endl;
	cout << "Info: " << f->getInfo() << endl;

	cout << " = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" << endl;
	f = new PigFeederDecorator(f);
	hour = 2;
	f->setWorkHour(hour);
	cout << "After decorated by PigFeederDecorator: \n";
	cout << "Description: " << f->Description() << "\n Salary: after do " << hour << " hours' work, shall receive " << f->Salary() << endl;
	cout << "Info: " << f->getInfo() << " Note that ID is not changed." << endl;

}
void Delegate_Pattern_test()
{
	cout << "Enter animal name: ";
	string ch3;
	cin >> ch3;

	Animal * a = Farmer::sales->findAnimal(SpeciesType(1), ch3);
	if (a == NULL) {
		cout << "Could not find one " << endl;
	}
	if (a->getChild() == 0)
	{
		cout << a->Species() << ": " << a->getName() << ": " << a->getSex() << ": No Child." << endl;   //getChild to find how many child this sheep has
	}
	cout << a->Species() << ": " << a->getName() << ": " << a->getSex() << ": " << a->getChild() << " Children." << endl;   //getChild to find how many child this sheep has
	cout << "Chileren's Names: ";
	TraverseList(a);
	cout << endl;
}
void Command_Pattern_test()
{
	EnvironmentManager *enManager = new EnvironmentManager();
	int ch2;
	cout << "\nNow you can do th following commands:\n"
		<< "Press 1:\t to reset the temperature\n"
		<< "Press 2:\t to reset the humidity level\n"
		<< "Press 3:\t to reset the illumination level\n"
		<< "Now please input your command:\t";
	cin >> ch2;
	int set_value = 0;
	switch (ch2)
	{
	case 1:
	{
		cout << "Please input the temperature value you want to set:\t";
		cin >> set_value;
		enManager->set_tem(set_value);
		break;
	}
	case 2:
	{
		cout << "Please input the humility level you want to set:\t";
		cin >> set_value;
		enManager->set_humi(set_value);
		break;
	}
	case 3:
	{
		cout << "Please input the illumination level you want to set:\t";
		cin >> set_value;
		enManager->set_illu(set_value);
		break;
	}
	default:
	{
		cout << "\nWrong command!\n";
		break;
	}
	}
}
void Builder_Pattern_test()
{
	int ch2;
	Gardener gardener;
	cout << "\nNow you can do the following commands:"
		<< "\nPress 1:\tto plant a rose"
		<< "\nPress 2:\tto plant a dandelion"
		<< "Now please input your command:\t";
	cin >> ch2;
	switch (ch2)
	{
	case 1:
	{
		FlowerBuilder *roseBuilder = new RoseBuilder();
		gardener.setFlowerBuilder(roseBuilder);
		gardener.plantFlower();
		Flower *flower = gardener.getFlower();
		cout << "Plant a rose successfully!\n";
		break;
	}
	case 2:
	{
		FlowerBuilder *dandelionBuilder = new DandelionBuilder();
		gardener.setFlowerBuilder(dandelionBuilder);
		gardener.plantFlower();
		Flower *flower = gardener.getFlower();
		cout << "Plant a dandelion successfully!\n";
		break;
	}
	default:
	{
		cout << "\nWrong command!\n";
		break;
	}
	}
}
void State_Pattern_test()
{
	cout << "Enter animal name: ";
	string ch3;
	cin >> ch3;
	Animal* a = Farmer::sales->findAnimal(SpeciesType(1), ch3);
	if (a == NULL) {
		cout << "Could not find one " << endl;
	}
	cout << "Enter animal state: 1. HUNGRY, 2. HAPPY, 3. SAD\n";
	int state;
	cin >> state;
	if (state < 4 && state > 0) {
		a->setCallStrategy(1, state);
		a->doCall();
	}
}



void InitialAnimalList()
{
	Farmer::sales->addAnimal(SHEEP, "sheep1", MALE);
	Farmer::sales->addAnimal(CATTLE, "cattle1", FEMALE);
	Farmer::sales->addAnimal(CHICKEN, "chicken1", MALE);
	Farmer::sales->addAnimal(DUCK, "duck1", FEMALE);
	Farmer::sales->addAnimal(FISH, "fish1", MALE);
	Farmer::sales->addAnimal(PIG, "pig1", FEMALE);
	Farmer::sales->addAnimal(DOG, "dog1", MALE);
}
void TraverseList(Animal* animal)
{
	Iterator<Animal>* iter = animal->createIterator();
	while (!iter->isDone())
	{
		cout << iter->currentItem()->getName() << "; ";
		TraverseList(iter->currentItem());
		iter->next();
	}
	return;
}
FoodType foodAcc(int type) {
	//1. SHEEP 2. CATTLE, 3. CHICKEN, 4. DUCK, 5. FISH, 6. PIG, 7. DOG
	switch (type) {
	case 1:
		return forSheep;
	case 2:
		return forCattle;
	case 3:
		return forChicken;
	case 4:
		return forDuck;
	case 5:
		return forFish;
	case 6:
		return forPig;
	case 7:
		return forDog;

	default:
		return forSheep;

	}
}

void AnimalProxy(int i, string ss, string s) {
	cout << "This is a wonderful morning !\n";
	if (i == 1)
	{
		//create proxy of sheep
		//When you call this function, the sheep will really do the morning exercise
		ProxySheep sheep;
		sheep.doExercise(ss, s);

	}
	if (i == 2)
	{
		//create proxy of cattle
		//When you call this function, the cattle will really do the morning exercise
		ProxyCattle cattle;
		cattle.doExercise(ss, s);
	}
	if (i == 3)
	{
		//create proxy of chicken
		//When you call this function, the chicken will really do the morning exercise
		ProxyChicken chick;
		chick.doExercise(ss, s);
	}
	if (i == 4)
	{
		//create proxy of duck
		//When you call this function, the duck will really do the morning exercise
		ProxyDuck duck;
		duck.doExercise(ss, s);
	}
	if (i == 5)
	{

		//create proxy of fish
		//When you call this function, the fish will really do the morning exercise
		ProxyFish fish;
		fish.doExercise(ss, s);
	}
	if (i == 6)
	{
		//create proxy of pig
		//When you call this function, the pig will really do the morning exercise
		ProxyPig pig;
		pig.doExercise(ss, s);
	}
	if (i == 7)
	{
		//create proxy of dog
		//When you call this function, the dog will really do the morning exercise
		ProxyDog dog;
		dog.doExercise(ss, s);
	}
}

