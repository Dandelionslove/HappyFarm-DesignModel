#ifndef FeedDecorator_hpp
#define FeedDecorator_hpp

#include <iostream>
#include "Staff.h"

class FeederDecorator: public Feeder {
protected:
    Feeder* pFeeder;
    string type;

public:
    virtual ~FeederDecorator() {cout << "feeder decorator dtor" <<endl;}
    FeederDecorator(Feeder* feeder) {pFeeder = feeder;}
    virtual int getID() {return pFeeder->getID(); }
    string Description() {return pFeeder->Description() + " " + type;}
    virtual void setBalance(double balance) {pFeeder->setBalance(balance);} // add shuqin
    virtual string getInfo() { return pFeeder->getInfo();} // add shuqin
    virtual void setWorkHour(double hour) { workHour = hour;} // add shuqin

};

class FishFeederDecorator: public FeederDecorator{
private:
    double wagePerHour = 5.0;
public:
    ~FishFeederDecorator() {delete pFeeder; cout << "FishFeederDecorator dtor" << endl;}
    FishFeederDecorator(Feeder* feeder);
    string Description();
    double Salary();
    void goodWorking();
};

class PigFeederDecorator: public FeederDecorator{
private:
    const double wagePerHour = 5.0;
    
public:
    ~PigFeederDecorator();
    PigFeederDecorator(Feeder* feeder);
    string Description();
    double Salary();
    void goodWorking();
};

class SheepFeederDecorator: public FeederDecorator{
private:
    double wagePerHour = 5.0;
    
public:
    ~SheepFeederDecorator();
    SheepFeederDecorator(Feeder* feeder);
    string Description();
    double Salary();
    void goodWorking();
};

class ChickenFeederDecorator: public FeederDecorator{
private:
    double wagePerHour = 5.0;
public:
    ~ChickenFeederDecorator() {delete pFeeder; cout << "ChickenFeederDecorator dtor" << endl;}
    ChickenFeederDecorator(Feeder* feeder);
    string Description();
    double Salary();
    void goodWorking();
};

class CattleFeederDecorator: public FeederDecorator{
private:
    double wagePerHour = 3;
    
public:
    ~CattleFeederDecorator() {delete pFeeder; cout << "CattleFeederDecorator dtor" << endl;}
    CattleFeederDecorator(Feeder* feeder);
    double Salary();
    string Description();
    void goodWorking();
};

class DogFeederDecorator: public FeederDecorator{
private:
    const double wagePerHour = 5.0;
    double workHour = 0;
public:
    ~DogFeederDecorator() {delete pFeeder; cout << "DogFeederDecorator dtor" << endl;}
    DogFeederDecorator(Feeder* feeder);
    string Description();
    double Salary();
    void goodWorking();
};

class DuckFeederDecorator: public FeederDecorator{
private:
    const double wagePerHour = 5.0;
public:
    ~DuckFeederDecorator() {delete pFeeder; cout << "DuckFeederDecorator dtor" << endl;}
    DuckFeederDecorator(Feeder* feeder);
    string Description();
    double Salary();
    void goodWorking();
};


#endif /* FeedDecorator_hpp */
