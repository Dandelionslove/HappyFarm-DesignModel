#pragma once
#include<iostream>
#include<cstdlib>
using namespace std;

class Flower
{
private:
	string color;
	string name;
public:
	Flower()
	{
		color = " ";
		name = " ";
	}
	~Flower(){}
	void setColor(string _color) { this->color = _color; }
	void setName(string _name) { this->name = _name; }
	
};

/*    Abstract Builder   */
class FlowerBuilder
{
protected:
	Flower *flower;
public:
	Flower* getFlower() { return flower; }
	void createNewFlower() { flower = new Flower(); }
	virtual void buildColor()=0;
	virtual void buildName()=0;
};

/*   Concrete Builder   */
class RoseBuilder :public FlowerBuilder
{
public:
	void buildColor() { flower->setColor("red"); cout << "RoseBuilder:buildColor:red\n"; }
	void buildName() { flower->setName("rose"); cout << "RoseBuilder:buildName:rose\n"; }
};

/*   Concrete Builder   */
class DandelionBuilder :public FlowerBuilder
{
public:
	void buildColor() { flower->setColor("white"); cout << "DandelionBuilder:buildColor:white\n";}
	void buildName() { flower->setName("Dandelion"); cout << "DandelionBuilder:buildName:Dandelion\n"; }
};

/*   Director   */
class Gardener
{
private:
	FlowerBuilder *flowerBuilder;
public:
	Gardener()
	{
		cout << "Gardener:ctor:created!\n";
	}
	void setFlowerBuilder(FlowerBuilder *fb) { flowerBuilder = fb; }
	Flower* getFlower() 
	{ 
		cout << "Gardener::getFlower()\n";
		return flowerBuilder->getFlower();
	}
	void plantFlower()
	{
		flowerBuilder->createNewFlower();
		flowerBuilder->buildColor();
		flowerBuilder->buildName();
	}
};