#include<iostream>
#include<cstdio>
#include"Sales.h"



Sales::Sales()
{
	dept_name = "Sales";
	dept_id = 4;
	sum = 0;
//     Department::department_staff.push_back(&staffs);

}

void Sales::createStaff(string name)
{
	staffs.push_back(new Salesman(name));
}

bool Sales::removeStaff(int staff_id)
{
    cout << "Sales: removeStaff: ";

	for (int i = 0; i<staffs.size(); ++i)
		if (staffs[i]->getID() == staff_id) {
			for (int j = i + 1; j < staffs.size(); ++j) staffs[j - 1] = staffs[j];
            delete *(staffs.end()-1);
            staffs.pop_back();
            cout << "remove successully!" << endl;
			return true;
		}
    cout << "staff with ID " << staff_id << "may not exist in sales department"  << endl;

	return false;
}

void Sales::showStaff()
{
    cout << "Sales: showStaff: " << endl;
	for (int i = 0; i < staffs.size(); ++i) {
		cout << staffs[i]->getInfo() << endl;
	}
}

Staff* Sales::assignJob(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            staffs[i]->work();
            cout <<"Sales: assignJob: assign job to " << staffs[i]->getInfo() << " successfully!" << endl;
            return staffs[i];
        }
    }
    cout << "Sales: assignJob: the target staff with ID "<< ID <<" either not exists or is not a saleman"<< endl;
	return NULL;
}

void Sales::addCustomer(Businessman* businessman) {
    customer.push_back(businessman);
    cout << "Sales:" << dept_name << ":addCustomer:" << "I'm adding new customer "<< businessman->getName() << "." << endl;
}
void Sales::supplyListChanged() {
    for (int i = 0; i < customer.size(); i++)
    {
        customer[i]->readNewSupply();
    }
    AnimalNum::ShowAnimals();
}


Staff* Sales::findStaff(int ID) {
    for(int i = 0; i < staffs.size(); i++) {
        if (staffs[i]->getID() == ID) {
            return staffs[i];
        }
    }
    return NULL;
}



AnimalList<Sheep> Sales::sheepList = AnimalList<Sheep>();
AnimalList<Duck> Sales::duckList = AnimalList<Duck>();
AnimalList<Dog> Sales::dogList = AnimalList<Dog>();
AnimalList<Fish> Sales::fishList = AnimalList<Fish>();
AnimalList<Chicken> Sales::chickenList = AnimalList<Chicken>();
AnimalList<Pig> Sales::pigList = AnimalList<Pig>();
AnimalList<Cattle> Sales::cattleList = AnimalList<Cattle>();


void Sales::addAnimal(SpeciesType type, string name, SexType sex) {
    if (type == SHEEP) {
        Sales::sheepList.addAnimal(type, name, sex);
    } else if (type == DOG) {
        Sales::dogList.addAnimal(type, name, sex);
    } else if (type == DUCK) {
        Sales::duckList.addAnimal(type, name, sex);
    } else if (type == PIG) {
        Sales::pigList.addAnimal(type, name, sex);
    } else if (type == CATTLE) {
        Sales::cattleList.addAnimal(type, name, sex);
    } else if (type == FISH) {
        Sales::fishList.addAnimal(type, name, sex);
    }else if (type == CHICKEN) {
        Sales::chickenList.addAnimal(type, name, sex);
    } else {
        cout << "addAnimal: type not exist" << endl;
    }
}

//Add by LY
/* Begin */
Animal* Sales::removeAnimal(SpeciesType type, string name)
{
	if (type == SHEEP) {
		return Sales::sheepList.Remove(name);
	}
	else if (type == DOG) {
		return Sales::dogList.Remove(name);
	}
	else if (type == DUCK) {
		return Sales::duckList.Remove(name);
	}
	else if (type == PIG) {
		return Sales::pigList.Remove(name);
	}
	else if (type == CATTLE) {
		return Sales::cattleList.Remove(name);
	}
	else if (type == FISH) {
		return Sales::fishList.Remove(name);
	}
	else if (type == CHICKEN) {
		return Sales::chickenList.Remove(name);
	}
	else {
		cout << "addAnimal: type not exist" << endl;
	}
	return NULL;
}
/* End */

Animal* Sales::findAnimal(SpeciesType type, string name) {
    if (type == SHEEP) {
        return Sales::sheepList.Find(name);
    } else if (type == DOG) {
        return Sales::dogList.Find(name);

    } else if (type == DUCK) {
        return Sales::duckList.Find(name);

    } else if (type == PIG) {
        return Sales::pigList.Find(name);

    } else if (type == CATTLE) {
        return Sales::cattleList.Find(name);

    } else if (type == FISH) {
        return Sales::fishList.Find(name);

    }else if (type == CHICKEN) {
        return Sales::chickenList.Find(name);

    } else {
        cout << "addAnimal: type not exist" << endl;
    }
    return NULL;
}

