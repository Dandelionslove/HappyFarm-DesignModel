#include<iostream>
#include<cstdio>
#include<string>
#include"FarmFactory.h"
#include "Farmer.h"

using namespace std;

void FarmFactory::createStaff(string type,string name)
{
	bool flag = false;
	if (type == "feeding") {
		Farmer::feeding->createStaff(name);
		flag = true;
	}
	else if (type == "cleaning") {
		Farmer::cleaning->createStaff(name);
		flag = true;
	}
	else if (type == "hospital") {
		Farmer::hospital->createStaff(name);
		flag = true;
	}
	else if (type == "sales") {
		Farmer::sales->createStaff(name);
		flag = true;
	}
	if (flag == true)
        cout << "FarmFactory: createStaff: " << "Successfully hire staff " << name << " into " << type << " department." << endl;
	else {
		cout << "FarmFactory: createStaff: " << "Fail to hire staff " << name << " into " << type << " department." << endl;
		cout << "                          Department " << type << " doesn't exist." << endl;
	}
}

void FarmFactory::removeStaff(string type, int staff_id)
{
	bool flag = false;
	if (type == "feeding") {
		flag = Farmer::feeding->removeStaff(staff_id);
		if (flag == true)cout << "FarmFactory: removeStaff: " << "Successfully dismiss staff " << staff_id << " in " << type << " department." << endl;
		else cout << "FarmFactory: removeStaff: " << "Staff " << staff_id << " doesn't exist in department " << type << "." << endl;
	}
	else if (type == "cleaning") {
		flag = Farmer::cleaning->removeStaff(staff_id);
		if (flag == true)cout << "FarmFactory: removeStaff: " << "Successfully dismiss staff " << staff_id << " in " << type << " department." << endl;
		else cout << "FarmFactory: removeStaff: " << "Staff " << staff_id << " doesn't exist in department " << type << "." << endl;
	}
	else if (type == "sales") {
		flag = Farmer::sales->removeStaff(staff_id);
		if (flag == true)cout << "FarmFactory: removeStaff: " << "Successfully dismiss staff " << staff_id << " in " << type << " department." << endl;
		else cout << "FarmFactory: removeStaff: " << "Staff " << staff_id << " doesn't exist in department " << type << "." << endl;
	}
	else if (type == "hospital") {
		flag = Farmer::hospital->removeStaff(staff_id);
		if (flag == true)cout << "FarmFactory: removeStaff: " << "Successfully dismiss staff " << staff_id << " in " << type << " department." << endl;
		else cout << "FarmFactory: removeStaff: " << "Staff " << staff_id << " doesn't exist in department " << type << "." << endl;
	}
	else cout << "FarmFactory: removeStaff: " << "Department " << type << " doesn't exist." << endl;
}

void FarmFactory::showStaff(string type)
{
	if (type == "feeding") {
		Farmer::feeding->showStaff();
	}
	else if (type == "cleaning") {
		Farmer::cleaning->showStaff();
	}
	else if (type == "sales") {
		Farmer::sales->showStaff();
	}
	else if (type == "hospital") {
		Farmer::hospital->showStaff();
    } 
	else {
        Farmer::feeding->showStaff();
        Farmer::cleaning->showStaff();
        Farmer::sales->showStaff();
        Farmer::hospital->showStaff();
    }
}

Staff* FarmFactory::findStaff(int id) {
    Staff* s = Farmer::feeding->findStaff(id);
    if (!s) {
        s = Farmer::cleaning->findStaff(id);
        if (!s) {
            s = Farmer::sales->findStaff(id);
            if (!s) {
                s = Farmer::hospital->findStaff(id);
                return s;
            } else
                return s;
        } else
            return s;
    } else 
        return s;
}
