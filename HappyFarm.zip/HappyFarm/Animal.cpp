#pragma once
#include"Animal.h"
Animal::~Animal()
{

}

bool Animal::setCallStrategy(int species, int state)
{
	delete _callStrategy;
	if (species == Sheep)
		_callStrategy = new SheepCallStrategy(state);
	else if (species == Cattle)
		_callStrategy = new CattleCallStrategy(state);
	else if (species == Chicken)
		_callStrategy = new ChickenCallStrategy(state);
	else if (species == Duck)
		_callStrategy = new DuckCallStrategy(state);
	else if (species == Fish)
		_callStrategy = new FishCallStrategy(state);
	else if (species == Pig)
		_callStrategy = new PigCallStrategy(state);
	else if (species == Dog)
		_callStrategy = new DogCallStrategy(state);
	else
		return false;
	return true;
}

void Animal::doCall()
{
	if (_species == 1)
		cout << "Sheep: ";
	else if (_species == 2)
		cout << "Cattle: ";
	else if (_species == 3)
		cout << "Chicken: ";
	else if (_species == 4)
		cout << "Duck: ";
	else if (_species == 5)
		cout << "Fish: ";
	else if (_species == 6)
		cout << "Pig: ";
	else if (_species == 7)
		cout << "Dog: ";
	cout << _name << ": " << getSex() << ": ";

	_callStrategy->format();
}

void Animal::BornChild()
{
	if (_sex == Female)
	{
		int species = _species;
		string name;
		cout << "Input Child Name:";
		cin >> name;
		srand((unsigned)time(NULL));
		int sex = rand() % 3;
		Animal* newAnimal = CreateAnimal(species, name, sex);
		cout << _name << ": " << "Female" << ": " << "Born Child!" << endl;
		_objects.push_back(newAnimal);
		AnimalNum::addNum(species);
	}
	else
		cout << _name << ": " << _species << ": " << "Male" << ": Can't born Child." << endl;
}
//bool Animal::killChild(string name)
//{
//	return this->removeAnimal(name, this);
//}
/*
void Animal::addAnimal(int species, string name, int sex)
{
Animal* newAnimal = CreateAnimal(species, name, sex);
_objects.push_back(newAnimal);
}
*/
Animal* Animal::removeAnimal(string name, Animal* s_animal, bool& isRemoved)
{
	if (s_animal->_objects.size() != 0)
	{
		vector<Animal*>::iterator iter = s_animal->_objects.begin();
		Animal* a = s_animal;
		while (!(iter == s_animal->_objects.end()))
		{
			if (isRemoved)
				break;
			if ((*iter)->getName() == name)
			{
				a = *iter;
				iter = s_animal->_objects.erase(iter);
				for (int i = 0; i < a->getChild(); i++)
				{
					_objects.push_back(a->_objects[i]);
				}
				AnimalNum::reduceNum(a->getSpecies());
				isRemoved = true;
				break;
			}
			else
			{
				a = removeAnimal(name, *iter, isRemoved);
				iter++;
				if (iter == s_animal->_objects.end())
					break;
				//removeAnimal(name, *iter);
			}
		}
		if (isRemoved)
			return a;
		else
			return NULL;
	}
	return NULL;
}

Iterator<Animal>* Animal::createIterator()
{
	return new ConcreteIterator<Animal>(this);
}

Animal* Animal::operator[](int index)
{
	return _objects[index];
}

string Animal::getSex()
{
	if (_sex == 1)
		return "male";
	else
		return "female";
}

int Animal::getSpecies()
{
	return _species;
}

string Animal::Species()
{
	if (_species == Sheep)
		return "Sheep";
	else if (_species == Cattle)
		return "Cattle";
	else if (_species == Chicken)
		return "Chicken";
	else if (_species == Duck)
		return "Duck";
	else if (_species == Fish)
		return "Fish";
	else if (_species == Pig)
		return "Pig";
	else if (_species == Dog)
		return "Dog";

	return "wrong type!";
}

/*
Animal* Animal::Find(string const name, Animal* s_animal)
{
Animal* animal = this;
Iterator<Animal>* iter = s_animal->createIterator();
if (iter == NULL)
return NULL;
while (!iter->isDone())
{
if (iter->currentItem()->getName() == name)
{
animal = iter->currentItem();
break;
}
else
{
iter->next();
animal = Find(name, iter->currentItem());
}
}
return animal;
}
*/
Animal* Animal::Pop(const int cur)
{
	if (cur < getChild())
		return _objects[cur];
	else
		return NULL;
}

void Animal::Eat(FoodType foodType)
{
	//setFood();
	if (Food::getCount(foodType) > 0)
	{
		doEat();
		Food::find_reduce_one(foodType);
		cout << Food::getCount(foodType) << " left.\n";
	}
	else
	{
		cout << "No food to eat!";
	}
}

int AnimalNum::_animalNum[7];

