#pragma once
#include<cstdio>
#include<string>
#include<iostream>
#include"Animal.h"
using namespace std;

class Businessman
{
	string name, phone_no;
public:
	Businessman() {}
	Businessman(string _name, string _phone) :name(_name), phone_no(_phone) { cout << "Businessman:" << _name << ":Businessman:" << "I'm created."<< endl; }
	void readNewSupply() const;
	string toString() const;
    string getName() { return name; }
    string getPhone() { return phone_no; }
};
