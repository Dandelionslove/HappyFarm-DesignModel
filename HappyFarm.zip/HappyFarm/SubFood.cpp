#include"SubFood.h"
FoodforCattle FoodforCattle::foodforCattle;
int FoodforCattle::count = 0;

FoodforChicken FoodforChicken::foodforChicken;
int FoodforChicken::count = 0;

FoodforDog FoodforDog::foodforDog;
int FoodforDog::count = 0;
FoodforDuck FoodforDuck::foodforDuck;
int FoodforDuck::count = 0;
FoodforFish FoodforFish::foodforFish;
int FoodforFish::count = 0;
FoodforPig FoodforPig::foodforPig;
int FoodforPig::count = 0;
FoodforSheep FoodforSheep::foodforSheep;
int FoodforSheep::count = 0;