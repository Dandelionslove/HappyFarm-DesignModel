#include"Businessman.h"

void Businessman::readNewSupply() const{
    cout << "Businessman:" << name << ":readNewSupply:" << "I'm checking the latest supply list of farm..."<< endl;
}
string Businessman::toString() const{
	return string(name + " (" + phone_no + ") ");
}
