#ifndef CleanerDecorator_hpp
#define CleanerDecorator_hpp

#include <iostream>
#include <string>
#include "Staff.h"
using namespace std;

class CleanerDecorator: public Cleaner  {
protected:
    Cleaner *pCleaner;
    string type;
public:
    virtual ~CleanerDecorator() {cout << "CleanerDecorator dtor" <<endl;}
    CleanerDecorator(Cleaner* cleaner) {pCleaner = cleaner;}
    virtual int getID() {return pCleaner->getID(); }
    virtual void setBalance(double balance) {pCleaner->setBalance(balance);} // add shuqin
	virtual string getInfo() { if (pCleaner != NULL)return pCleaner->getInfo(); else return "no cleaner in the farm"; } // add shuqin
    virtual void setWorkHour(double hour) { workHour = hour;} // add shuqin
};

class DomesticCleanerDecorator: public CleanerDecorator{
private:
    double wagePerHour = 5.0;
public:
    ~DomesticCleanerDecorator() {delete pCleaner; cout << "DomesticCleanerDecorator dtor" << endl;}
    DomesticCleanerDecorator(Cleaner* cleaner);
    
    string Description() {return pCleaner->Description() + " " + type;}
    double Salary() {return wagePerHour * workHour + pCleaner->Salary();}
};

class PoultryCleanerDecorator: public CleanerDecorator{
private:
    double wagePerHour = 2.0;

public:
    ~PoultryCleanerDecorator();
    PoultryCleanerDecorator(Cleaner* cleaner);
    string Description() {return pCleaner->Description() + " " + type;}
    double Salary() {return wagePerHour * workHour + pCleaner->Salary();}
};

#endif /* CleanerDecorator_hpp */
