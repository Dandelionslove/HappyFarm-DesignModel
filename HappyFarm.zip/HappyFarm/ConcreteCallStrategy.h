#pragma once
#include <iostream>
#include "CallStrategy.h"
using namespace std;

/*Concrete call strategy of each animal*/

//Sheep
class SheepCallStrategy: public CallStrategy
{
public:
	SheepCallStrategy(int state): CallStrategy(state){}
private:
	void call()
	{
		cout << "Baa ";
	}
};

//Cattle
class CattleCallStrategy : public CallStrategy
{
public:
	CattleCallStrategy(int state) : CallStrategy(state) {}
private:
	void call()
	{
		cout << "Moo ";
	}
};

//Chicken
class ChickenCallStrategy : public CallStrategy
{
public:
	ChickenCallStrategy(int state) : CallStrategy(state) {}
private:
	void call()
	{
		cout << "Cluck ";
	}
};

//Duck
class DuckCallStrategy : public CallStrategy
{
public:
	DuckCallStrategy(int state) : CallStrategy(state) {}
private:
	void call()
	{
		cout << "Quack ";
	}
};

//Fish
class FishCallStrategy : public CallStrategy
{
public:
	FishCallStrategy(int state) : CallStrategy(state) {}
private:
	void call()
	{
		cout << "Bubbling ";
	}
};

//Pig
class PigCallStrategy : public CallStrategy
{
public:
	PigCallStrategy(int state) : CallStrategy(state) {}
private:
	void call()
	{
		cout << "Grunt ";
	}
};

//Dog
class DogCallStrategy : public CallStrategy
{
public:
	DogCallStrategy(int state) : CallStrategy(state) {}
private:
	void call()
	{
		cout << "Bark ";
	}
};