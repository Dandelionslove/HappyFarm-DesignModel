#include "Food.h"
Food* Food:: prototypes[];
int Food:: nextSlot=0;
vector<Food*> Food::foods = vector<Food*>();
Food* Food::find_add_one(FoodType type)
{
    for (int i=0; i<nextSlot; i++)
    {
        if (prototypes[i]->returnType()==type)
        {
            Food* f = prototypes[i]->clone();
            foods.push_back(f);
            return f;
        }
    }
    
    return NULL;
}
void Food:: find_reduce_one(FoodType type)
{
    vector<Food*>::iterator it;
    cout << foods.size() << endl;
    
    for (int i = 0; i < foods.size(); i++) {
        if (foods[i]->returnType() == type) {
            delete foods[i];
            foods.erase(foods.begin() + i);
            //            foods[i]->Delete();
            break;
        }
    }
    cout << foods.size() << endl;
}
int Food:: getCount(FoodType type)
{
    
    for (int i=0; i<nextSlot; i++)
    {
        if (prototypes[i]->returnType()==type)
            return prototypes[i]->returnCount();
    }
    return 0;
}
