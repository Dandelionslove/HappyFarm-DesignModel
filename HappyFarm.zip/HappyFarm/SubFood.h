#ifndef SubFood_h
#define SubFood_h
#include <iostream>
using namespace std;
#include "Food.h"


//forCattle
class FoodforCattle: public Food
{
public:
    FoodType returnType(){return forCattle;}
    Food* clone(){return new  FoodforCattle(1);}
    ~FoodforCattle(){count--; cout<<"FoodforCattle dctor ";}
    int returnCount(){return count;}
    void Delete(){count--;}
protected:
    FoodforCattle(int temp){ count++; }
private:
    static FoodforCattle foodforCattle;
    FoodforCattle(){ addPrototype(this); }
    static int  count;
};

//forChicken
class FoodforChicken: public Food
{
public:
    FoodType returnType() {return forChicken;}
    Food* clone() {return new  FoodforChicken(1);}
    ~FoodforChicken() {count--; cout<<"FoodforChicken dctor ";}
    int returnCount() {return count;}
    void Delete() {count--;}
protected:
    FoodforChicken(int temp){count++;}
private:
    static FoodforChicken foodforChicken;
    FoodforChicken(){addPrototype(this);}
    static int  count;
};


//forDog
class FoodforDog: public Food
{
public:
    FoodType returnType() {return forDog;}
    Food* clone() {return new  FoodforDog(1);}
    ~FoodforDog() {count--; cout<<"FoodforDog dtor "<<endl;}
    int returnCount() {return count;}
    void Delete() {count--;}
protected:
    FoodforDog(int temp) {count++;}
private:
    static FoodforDog foodforDog;
    FoodforDog() {addPrototype(this);}
    static int  count;
};

//forDuck
class FoodforDuck: public Food
{
public:
    FoodType returnType(){return forDuck;}
    Food* clone(){return new  FoodforDuck(1);}
    ~FoodforDuck(){count--; cout<<"FoodforDuck dtor "<<endl;}
    int returnCount(){return count;}
    void Delete(){count--;}
protected:
    FoodforDuck(int temp){count++;}
private:
    static FoodforDuck foodforDuck;
    FoodforDuck(){addPrototype(this);}
    static int  count;
};

//forFish
class FoodforFish: public Food
{
public:
    FoodType returnType(){return forFish;}
    Food* clone(){return new  FoodforFish(1);}
    ~FoodforFish(){count--; cout<<"FoodforFish dtor "<<endl;}
    int returnCount(){return count;}
    void Delete(){count--;}
protected:
    FoodforFish(int temp){count++;}
private:
    static FoodforFish foodforFish;
    FoodforFish(){addPrototype(this);}
    static int  count;
};

//forPig
class FoodforPig: public Food
{
public:
    FoodType returnType(){return forPig;}
    Food* clone(){return new  FoodforPig(1);}
    ~FoodforPig(){count--; cout<<"FoodforPig dtor "<<endl;}
    int returnCount(){return count;}
    void Delete(){count--;}
protected:
    FoodforPig(int temp){count++;}
private:
    static FoodforPig foodforPig;
    FoodforPig(){addPrototype(this);}
    static int  count;
};

//forSheep
class FoodforSheep: public Food
{
public:
    FoodType returnType(){return forSheep;}
    Food* clone(){return new  FoodforSheep(1);}
    ~FoodforSheep(){count--; cout<<"FoodforSheep dtor "<<endl;}
    int returnCount(){return count;}
    void Delete(){count--;}
protected:
    FoodforSheep(int temp){count++;}
private:
    static FoodforSheep foodforSheep;
    FoodforSheep(){addPrototype(this);}
    static int  count;
};

#endif /* SubFood_h */
