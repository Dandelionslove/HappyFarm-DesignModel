#include "Status.h"


HealthState* HealthState::singleton = NULL;
UnhealthState* UnhealthState::singleton = NULL;

void Staff::changeState(State* state) {
    cout << "Staff: changeState: change to " << state->getName() << endl;
    this->state = state;
}

//void Staff::meeting() {
//    randHealthStatus();
//    state->meeting(this);
//}

void Staff::work() {
    randHealthStatus();
    state->work(this);
}

State* HealthState::getInstance() {
    if (singleton == NULL) {
        singleton = new HealthState();
    }
    return singleton;
}

State* UnhealthState::getInstance() {
    if (singleton == NULL) {
        singleton = new UnhealthState();
    }
    return singleton;
}



void HealthState::meeting(Staff *staff) {
    staff->goodMeeting();
}

void HealthState::work(Staff *staff) {
    staff->goodWorking();
}

void UnhealthState::meeting(Staff *staff) {
    staff->callingIll();
}

void UnhealthState::work(Staff *staff) {
    staff->callingIll();
}



