#ifndef Department_h
#define Department_h

#include<iostream>
#include<string>
#include<cstdio>
#include<vector>
#include"Staff.h"
//#include "Departments.h"

using namespace std;

class Department
{
protected:
    vector<Staff*> staffs;
public:
    Department();
    virtual ~Department();// {}
    
	string dept_name;
	int dept_id;
	static int sum;
	
    virtual void createStaff(string name) {};
    virtual bool removeStaff(int staff_id) {return false;};
    virtual void showStaff() {};

    void notifyMeeting();
    //virtual Staff* assignJob(int ID) {return NULL;} // shuqin
	virtual Staff* assignJob(int ID) { return NULL; } // shuqin
    virtual Staff* findStaff(int ID) {return NULL;}
};

class Feeding :public Department
{
private:
        //vector<Staff* > staffs;
    
public:
    Feeding();
    ~Feeding(){}
    void createStaff(string name);
    bool removeStaff(int staff_id);
    void showStaff();
    Staff* assignJob(int ID);
    
    Staff* findStaff(int ID);
};

class Hospital :public Department
    //Hospital Department
{
private:
        //vector<Staff* > staffs;
    
public:
    Hospital();
    ~Hospital(){}
    void createStaff(string name);
    bool removeStaff(int staff_id);
    void showStaff();
    Staff* assignJob(int ID);
    
    Staff* findStaff(int ID);
};

class Cleaning : public Department
{
private:
        //vector<Staff*> staffs;
public:
    
    Cleaning();
    ~Cleaning() {}
    void createStaff(string name);
    bool removeStaff(int staff_id);
    void showStaff();
    Staff* assignJob(int ID); // shuqin
        //void notifyMeeting();
    
    Staff* findStaff(int ID);
};


#endif /* Department_h */
