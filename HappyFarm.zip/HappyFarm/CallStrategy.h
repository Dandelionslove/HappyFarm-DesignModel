#pragma once
#include <iostream>
using namespace std;
class CallStrategy
{
public:
	enum StateType
	{ Hungry = 1, Happy, Sad};
	CallStrategy(int state): _state(state){}
	void format()
	{
		call();
		if (_state == Hungry)
			cout << "hungrily." << endl;
		else if (_state == Happy)
			cout << "happily." << endl;
		else if (_state == Sad)
			cout << "sadly." << endl;
	}
protected:
		int _state;
private:
	virtual void call() = 0;
};