#include "Staff.h"

// every staff should enter a name.
// health status, work status and id is implicitly set
int Staff::id_Available = 0;
Staff::Staff(string name) {

    this->name = name;
    
    this->id = Staff::id_Available;
    Staff::id_Available++;
    
    health_status = true;
    
    work_status = false; // all staff is initially set as not working
    
    workHour = 0;
    
    wagePerHour = 1; // default as 1
    
    balance = 0;
    
}



string Staff::getInfo() {
    return type + ": ID: " + to_string(id) + " Name: " + name;
}



void Staff::callingIll() {
    cout << "Staff: callingIll: staff with info " << getInfo() << "is deadly ill, can't move!" << endl;
}

void Staff::randHealthStatus(int p) {
    srand(0);
    
    if (p > 1 || p <= 0) {
        p = 0.15;
    }
    if (rand()%1 < p) {
        changeState(UnhealthState::getInstance());
    } else {
        changeState(HealthState::getInstance());
    }
}

Cleaner::Cleaner(string name): Staff(name) {
    type = "cleaner";
}

void Cleaner::goodMeeting() {
    cout << "Cleaner:" << name << ":meeting:" << "I'm notified to attend meeting at CLEANING CENTER..."<< endl;
}


void Cleaner:: goodWorking() {
    cout << "Cleaner: work: " << name <<" :do job clean..." << endl;
}

Vetaritarian::Vetaritarian(string name):Staff(name) {
    type = "vetaritarian";
}

void Vetaritarian::goodMeeting() {
    cout << "Vetaritarian:" << name << ":meeting:" << "I'm notified to attend meeting at HOSPITAL..."<< endl;
}

Feeder::Feeder(string name): Staff(name) {
    type = "feeder";
}

void Feeder::goodMeeting() {
    cout << "Feeder:" << name << ":meeting:" << "I'm notified to attend meeting at FEEDING CENTER..."<< endl;
    
}

Salesman::Salesman(string name) :Staff(name) {
    type = "salesman";
}

void Salesman::goodMeeting() {
    cout << "Salesman:" << name << ":meeting:" << "I'm notified to attend meeting at SALES CENTER..."<< endl;
    
}