#include<iostream>
#include<cstdio>
#include<string>
#include "Farmer.h"

Farmer* Farmer::uniquefarmer = NULL;     //Initialize the unique instance.
// !!!!
FarmFactory* Farmer::farm = new FarmFactory();
Cleaning* Farmer::cleaning  =new Cleaning();
Feeding* Farmer::feeding = new Feeding();
Sales* Farmer::sales = new Sales();
Hospital* Farmer::hospital  =new Hospital();


Farmer* Farmer::getInstance() {
    if (uniquefarmer == NULL) {
        uniquefarmer = new Farmer("Farmer", "Farm");
    }
    return uniquefarmer;
}
Farmer* Farmer::getInstance(string farmer_name, string farm_name) //Instantiate the object and return the object.
{
	if(uniquefarmer == NULL)                                      //If the unique instance isn't null,the unique instance has been created.
	uniquefarmer = new Farmer(farmer_name, farm_name);
	cout<<"Farmer:getInstance:"<<"The farmer named "<<uniquefarmer->farmer_name<<" has created the "<<uniquefarmer->farm_name<<" farm."<<endl;
	return uniquefarmer;
}
				
void Farmer::cleanInstance() //Clear the instance.
{
    delete uniquefarmer;
	uniquefarmer = NULL;
}

void Farmer::PaySalary(int staff_id) //The farmer pays for the staff's salary.
{
    Staff* staff = Farmer::farm->findStaff(staff_id);
    if (staff == NULL) {
        cout << "Id" <<staff_id << " not exist" << endl;
        return;
    }
    cout << "How many hours does " << staff->getName() << "worked? ";
    double hour = 0;
    cin >> hour;
    staff->setWorkHour(hour);
    cout<<"Farmer:PaySalary: "<<farmer_name<<" has paid for the "<<staff->getName()<<"'s salary: $" << staff->Salary() <<endl;
    cout << "Now " << staff->getName() << "'s balance is " << staff->Balance()<<"."<<endl;
}


void Farmer::OpenFarm()                                   //The farmer opens the farm.
{
	if(farm_status==true)
	cout<<"Farmer:OpenFarm:"<<farmer_name<<"'s farm has been opened."<<endl;
	else
	{
	    farm_status=true; 
	    cout<<"Farmer:OpenFarm:"<<farmer_name<<"'s farm opened successfully."<<endl;
	}
}


void Farmer::CloseFarm()                                    //The farmer closes the farm.
{
	if(farm_status==false)
	cout<<"Farmer:CloseFarm:"<<farmer_name<<"'s farm has been closed."<<endl;
	else
	{
	    farm_status=false;
	    cout<<"Farmer:CloseFarm:"<<farmer_name<<"'s farm closed successfully."<<endl;
	}

}

void Farmer::Hire(string type, string name)
{
	Farmer::farm->createStaff(type, name);
}

void Farmer::Dismiss(string type, int staff_id)
{
	Farmer::farm->removeStaff(type, staff_id);
}

void Farmer::DisplayStaff(string type)
{
	Farmer::farm->showStaff(type);
}

