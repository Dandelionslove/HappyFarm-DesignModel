#ifndef Status_hpp
#define Status_hpp

#include <iostream>
#include <string>
#include "Staff.h"
using namespace std;
class Staff;

class State {
    
public:
    virtual void work(Staff* staff) {}
    virtual void meeting(Staff* staff) {}
    string getName() {return "state";}
};

class HealthState: public State {
private:
    HealthState(){}
    ~HealthState(){}

    static HealthState* singleton;
public:
    virtual void work(Staff* staff);
    virtual void meeting(Staff* staff);
    
    static State* getInstance();
    string getName() {return "health " + State::getName();}

};

class UnhealthState: public State {
private:
    UnhealthState(){}
    ~UnhealthState(){}
    static UnhealthState* singleton;
public:
    virtual void work(Staff* staff);
    virtual void meeting(Staff* staff);
    
    static State* getInstance();
    string getName() {return "unhealth " + State::getName();}

};


#endif /* Status_hpp */



