#include "FeederDecorator.h"

void FishFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forFish);
}

double FishFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

FishFeederDecorator :: FishFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "fish";
}

string FishFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}

void PigFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forPig);
}

double PigFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

PigFeederDecorator :: PigFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "pig";
}

string PigFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}

PigFeederDecorator::~PigFeederDecorator() {
    delete pFeeder;
    cout << "PigFeederDecorator dtor" << endl;
}


void SheepFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forSheep);
}

double SheepFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

SheepFeederDecorator :: SheepFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "sheep";
}


string SheepFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}

SheepFeederDecorator :: ~SheepFeederDecorator() {
    delete pFeeder;
    cout << "SheepFeederDecorator dtor" << endl;
}


void ChickenFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forChicken);
}

double ChickenFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

ChickenFeederDecorator :: ChickenFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "chicken";
}
string ChickenFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}



void CattleFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forCattle);
}

double CattleFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

CattleFeederDecorator :: CattleFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "cattle";
}
string CattleFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}

void DogFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forDog);
}

double DogFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

DogFeederDecorator :: DogFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "dog";
}

string DogFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}

void DuckFeederDecorator::goodWorking() {
    Food::find_add_one(FoodType::forDuck);
}

double DuckFeederDecorator :: Salary() {
    return wagePerHour * workHour + pFeeder->Salary();
}

DuckFeederDecorator :: DuckFeederDecorator(Feeder* feeder): FeederDecorator(feeder) {
    type = "duck";
}

string DuckFeederDecorator :: Description() {
    return pFeeder->Description() + " " + type;
}