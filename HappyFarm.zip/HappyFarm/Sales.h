#ifndef Sales_h
#define Sales_h
#include<iostream>
#include<string>
#include<cstdio>
#include<vector>
#include"Department.h"
#include "Businessman.h"
#include "Animal.h"
#include "Type.h"
using namespace std;

class Sales :public Department
//���۲�
{
private:
    vector<Staff*> staffs;
public:
    static AnimalList<Sheep> sheepList;
    static AnimalList<Cattle> cattleList;
    static AnimalList<Duck> duckList;
    static AnimalList<Dog> dogList;
    static AnimalList<Fish> fishList;
    static AnimalList<Chicken> chickenList;
    static AnimalList<Pig> pigList;

	
	Sales();
    ~Sales(){}
	void createStaff(string name);
	bool removeStaff(int staff_id);
	void showStaff();
    vector<Businessman*> customer;
    void addCustomer(Businessman*);
    void supplyListChanged();
	Staff* assignJob(int ID);
    
    Staff* findStaff(int ID);
    void addAnimal(SpeciesType type, string name, SexType sex);
    Animal* findAnimal(SpeciesType type, string name);
	Animal* removeAnimal(SpeciesType type, string name);  //Add by LY
};

#endif /* Sales_h */
