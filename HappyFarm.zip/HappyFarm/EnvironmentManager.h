#pragma once
#include "EnvironmentCommand.h"
#include<string>
class EnvironmentManager
{
public:
	EnvironmentManager()
	{
		tem_command = new Command(new Environment, &Environment::set_tem);
		humi_command = new Command(new Environment, &Environment::set_humi);
		illu_command = new Command(new Environment, &Environment::set_illu);
		cout << "EnvironmentManager: ctor :created\n";
	}
	void set_tem(int tem_value)
	{
		tem_command->execute(tem_value);
	}
	void set_humi(int humi_level)
	{
		humi_command->execute(humi_level);
	}
	void set_illu(int illu_level)
	{
		illu_command->execute(illu_level);
	}
private:
	////Create command object
	Command *tem_command;
	Command *humi_command;
	Command *illu_command;
};